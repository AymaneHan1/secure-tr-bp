# LLM Routing — Complete Open-Source Documentation Pack

*Researched and written October 2026. Every tool here is open source and self-hostable. Versions and features move fast in this space; each guide lists the official links to re-check before you deploy.*

This pack teaches you LLM routing from first principles to production, then gives you a setup → usage → deployment guide for every serious open-source option, written for **your** situation: a company-wide chatbot with **five models** behind **your own inference API** that already abstracts the LLM providers.

---

## How to read this pack

| If you have… | Read |
|---|---|
| 20 minutes | [`00-REPORT-comparison-and-decision-guide.md`](00-REPORT-comparison-and-decision-guide.md) — the executive summary, comparison matrix, and "which one when" |
| 2 hours | The report, then [`01-fundamentals/`](01-fundamentals/) (concepts + how routers plug into your API) |
| A week (full mastery) | Everything, in order. Then do the [build-your-own playbook](03-playbooks/01-build-your-own-router.md) on your real traffic |

## Folder map

```
llm-router-docs/
├── README.md                                   ← you are here
├── 00-REPORT-comparison-and-decision-guide.md  ← the report: differences, functionality, when to use what
├── 01-fundamentals/
│   ├── 01-routing-concepts.md                  ← theory: router families, signals, cost math, multi-turn traps
│   └── 02-integration-architecture.md          ← 3 ways to plug a router into YOUR inference API
├── 02-guides/                                  ← one setup/usage/deployment guide per solution
│   ├── 01-litellm-auto-router.md               ← gateway, complexity tiers, fastest to value
│   ├── 02-vllm-semantic-router.md              ← full Mixture-of-Models platform (Envoy, K8s)
│   ├── 03-plano-arch-router.md                 ← preference (domain/action) routing proxy
│   ├── 04-nemo-switchyard.md                   ← NVIDIA's Rust router, agent-oriented
│   ├── 05-routellm.md                          ← LMSYS strong/weak learned routers
│   ├── 06-llmrouter-uiuc.md                    ← 16+ trainable multi-model routers
│   ├── 07-aurelio-semantic-router.md           ← embedding intent routing library
│   └── 08-nvidia-complexity-classifier.md      ← DeBERTa task + complexity scorer
├── 03-playbooks/
│   ├── 01-build-your-own-router.md             ← end-to-end: data → labels → train → serve (full code)
│   ├── 02-evaluation-and-benchmarking.md       ← metrics, offline eval, shadow mode, A/B, RouterArena
│   └── 03-production-rollout-checklist.md      ← phased rollout, SLOs, monitoring, runbooks
└── 04-resources.md                             ← every link: repos, downloads, docs, models, papers, tutorials
```

## Conventions used in every guide

To keep examples concrete and comparable, every guide uses the same fictional setup. Replace names with yours.

**Your inference API** (already exists, abstracts providers):

```bash
export INFERENCE_API_BASE="https://inference.internal.example.com/v1"   # OpenAI-compatible
export INFERENCE_API_KEY="sk-internal-..."
```

**Your five models** (aliases as exposed by your API), ordered by cost:

| Alias | Role | Relative cost |
|---|---|---|
| `fast-mini` | Greetings, short factual Q&A, rewrites | 1× |
| `general-small` | Everyday questions, summaries, emails | ~3× |
| `general-large` | Analysis, long documents, nuanced writing | ~12× |
| `code-specialist` | Code generation, debugging, SQL | ~10× |
| `reasoning-frontier` | Hard multi-step reasoning, math, planning | ~40× |

> **Assumption:** your API exposes an OpenAI-compatible `/v1/chat/completions` endpoint. Every gateway in this pack speaks that protocol. If your API uses a custom protocol, use the **decision-only (sidecar)** pattern from [`02-integration-architecture.md`](01-fundamentals/02-integration-architecture.md), which needs no protocol compatibility at all.

**Labels used in the guides:**

- ✅ **Verified** — taken from official docs/READMEs at time of writing.
- ⚠️ **Verify** — a reasonable configuration that you must check against the current docs (schema details change between releases).
- 📊 **Vendor-reported** — numbers published by the project itself, not independently reproduced.

## The one-paragraph answer

If you want results this month, put **LiteLLM's Auto Router** in shadow mode in front of your five models, measure, then turn it on. If you want the best long-term quality/cost ratio, **train your own router on your own traffic** (playbook 01, optionally using **LLMRouter**'s implementations) and serve it as a **decision-only sidecar** called by your API. If you run Kubernetes and also want guardrails, semantic caching, and a dashboard in the routing layer, evaluate **vLLM Semantic Router**. The report explains why.
