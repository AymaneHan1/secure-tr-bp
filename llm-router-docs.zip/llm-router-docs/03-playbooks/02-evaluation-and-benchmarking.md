# Playbook 02 — Evaluating Routers: Offline, Shadow, Online, and Public Benchmarks

A router is only worth it if it **preserves most of the best model's quality at a meaningfully lower cost**. "Router accuracy" alone is misleading. This playbook gives you the metrics, the code, and a four-stage method that works for every tool in this pack.

---

## 1. Metrics

| Metric | Formula / meaning | Why |
|---|---|---|
| **Quality retained** | `Q_router / Q_best` (e.g., vs. always `reasoning-frontier`) | Headline quality number |
| **Cost saved** | `1 − Cost_router / Cost_baseline` | Headline money number (state the baseline!) |
| **Model mix** | % of traffic per model | Explains cost; detects drift |
| **APGR** | Average Performance Gap Recovered: area under `(Q_router − Q_weak)/(Q_strong − Q_weak)` across cost levels (RouteLLM paper) | Threshold-independent comparison of routers |
| **CPT(x%)** | Strong-call % needed to recover x% of the gap (RouteLLM paper) | "How much expensive traffic do I need?" |
| **Oracle gap** | `Cost_router − Cost_oracle` at equal quality | How far from perfect routing |
| **Under-route rate** | % routed to a model scoring > δ below the best | Quality risk |
| **Over-route rate** | % routed to a more expensive model than the oracle | Wasted money |
| **Router latency** | p50/p95/p99 decision time | UX |
| **Fallback rate** | % decisions that timed out/failed | Reliability |

### Code: evaluate any router on a labeled set

Input: `dataset.jsonl` from playbook 01 (scores and costs for all 5 models per prompt) and `decisions.jsonl` (`{"id", "model"}` from the router under test).

```python
# eval_router.py
import json, numpy as np

MODELS = ["fast-mini", "general-small", "general-large", "code-specialist", "reasoning-frontier"]
DELTA = 1
data = {r["id"]: r for r in map(json.loads, open("dataset.jsonl"))}
dec  = {d["id"]: d["model"] for d in map(json.loads, open("decisions.jsonl"))}
ids = [i for i in dec if i in data]

def stats(pick):
    q = np.mean([data[i]["scores"][pick(i)] for i in ids])
    c = np.sum([data[i]["costs"][pick(i)] for i in ids])
    return q, c

q_best, c_best = stats(lambda i: "reasoning-frontier")
q_weak, c_weak = stats(lambda i: "fast-mini")
q_r, c_r       = stats(lambda i: dec[i])
q_o, c_o       = stats(lambda i: data[i]["oracle"])

under = np.mean([data[i]["scores"][dec[i]] < max(data[i]["scores"].values()) - DELTA for i in ids])
over  = np.mean([data[i]["costs"][dec[i]] > data[i]["costs"][data[i]["oracle"]] for i in ids])
mix   = {m: round(sum(dec[i] == m for i in ids) / len(ids), 3) for m in MODELS}

print(f"n={len(ids)}")
print(f"quality retained : {q_r/q_best:.1%}   (router {q_r:.2f} / best {q_best:.2f})")
print(f"cost saved       : {1 - c_r/c_best:.1%} vs always-frontier")
print(f"gap recovered    : {(q_r - q_weak)/(q_best - q_weak):.1%}  (weak→strong)")
print(f"oracle           : quality {q_o:.2f}, cost saved {1 - c_o/c_best:.1%}")
print(f"under-route {under:.1%} | over-route {over:.1%}")
print("mix:", mix)
```

### Code: APGR for a scorer with a tunable knob

```python
import numpy as np

def apgr(q_router_at, q_weak, q_strong, knobs):
    """q_router_at(k) → mean quality at knob k (e.g., λ or threshold). Integrates the recovered gap over knobs."""
    gaps = [(q_router_at(k) - q_weak) / (q_strong - q_weak) for k in knobs]
    integrate = getattr(np, "trapezoid", None) or np.trapz   # NumPy 2.x renamed trapz → trapezoid
    return float(integrate(gaps, dx=1 / (len(knobs) - 1)))
```

Plot the **cost–quality curve** (x = cost saved, y = quality retained) for each candidate router plus the oracle and the single-model points. The best router is the one whose curve sits highest at your chosen cost.

---

## 2. Stage 1 — Offline evaluation (before any user sees it)

1. Hold out 20% of your labeled dataset (playbook 01) — never used for training or threshold tuning.
2. Run every candidate on the hold-out set:
   - **LiteLLM:** run the proxy with only the router alias and call the test-routing preview (or log `routed_model` from real calls to a mock backend).
   - **vLLM SR:** `vllm-sr route preview --json` per prompt.
   - **Plano:** call the router model directly with the route prompt, or log `resp.model`.
   - **RouteLLM / LLMRouter / Aurelio / NVIDIA / your sidecar:** call their Python APIs or `/route`.
3. Produce `decisions.jsonl` per router; run `eval_router.py`.
4. Slice results: by team, by language, by length bucket, by task type (code/non-code), by turn index (first turn vs. follow-ups). **Routers often fail on follow-ups.**

Acceptance gate example: ≥ 97% quality retained, ≥ 40% cost saved vs. current production mix, under-route rate < 5%, p95 latency < 50 ms.

---

## 3. Stage 2 — Shadow mode (real traffic, zero user impact)

Your API calls the router, logs the decision, but serves with the current model.

```sql
-- Example analysis on your decision log table
SELECT routed_model, served_model, COUNT(*) AS n,
       SUM(cost_usd)              AS actual_cost,
       SUM(est_cost_if_routed)    AS routed_cost
FROM routing_decisions
WHERE ts > now() - interval '7 days'
GROUP BY 1, 2 ORDER BY n DESC;
```

- Estimate cost with routed model prices × observed token counts (output tokens differ by model — apply a per-model output-length ratio from your playbook-01 data).
- Sample 200 conversations where `routed_model` is cheaper than `served_model`; generate the cheap model's answer offline; judge vs. the served answer. This directly estimates the quality risk of switching.

---

## 4. Stage 3 — Online A/B test

- **Unit:** user (not request) to avoid within-session inconsistency; 5–10% treatment to start.
- **Primary metrics:** cost per conversation; quality proxies — thumbs-down rate, regenerate rate, "that's wrong"-type follow-ups, conversation abandonment, escalation to human/helpdesk.
- **Guardrails (auto-stop):** thumbs-down +X% relative, latency p95 +Y ms, error rate.
- **Duration:** at least 1–2 business cycles (weekday/weekend patterns); compute sample size for your baseline thumbs-down rate before starting.
- **Ramp:** 5% → 25% → 50% → 100% with a kill switch (`ROUTER_ENABLED=false` → default model).

---

## 5. Stage 4 — Continuous evaluation in production

- Weekly judged sample per model (playbook 01, step 7).
- Drift detection: compare embedding centroid distribution of this week's prompts vs. training set; alert on new clusters (new use cases).
- Track the **model mix** and **cost/request** daily — sudden shifts mean either traffic changed or the router broke.
- Keep the oracle analysis running monthly to know how much headroom remains.

---

## 6. Public benchmarks (learn and compare, don't decide on them alone)

### RouterArena (Rice University, ICLR 2026)

- Open platform + **live leaderboard** comparing open-source and commercial routers on a principled dataset with domain coverage and difficulty levels; metrics include accuracy, cost, and router overhead (latency).
- Leaderboard: https://routeworks.github.io/ · Code: https://github.com/RouteWorks/RouterArena · Paper: https://arxiv.org/abs/2510.00202
- Workflow (from the README): install with `uv` (`uv sync`), download the dataset from Hugging Face, generate your router's prediction file, run the automated evaluation; to appear on the leaderboard, open a PR with the prediction file — the CI evaluates and posts results.
- Use it to sanity-check that your learned router isn't worse than published ones on general traffic.

### xRouteBench (UIUC, with LLMRouter)

- 8 datasets (classic NLP, memory, time-series, video, multimodal math, personalized); every query pre-run on 18 candidate LLMs, so evaluating **local** routers costs nothing (replay).
- https://huggingface.co/datasets/ulab-ai/xRouteBench · pipeline in `LLMRouter/benchmark_pipeline/`.

### RouteLLM eval harness

- `python -m routellm.evals.evaluate --routers random sw_ranking bert mf --benchmark gsm8k` (MMLU, GSM8K, MT-Bench), cached results for the GPT-4/Mixtral pair.

### RouterBench / RouterEval (earlier benchmarks)

- Earlier standardized router benchmarks (deferral-curve style evaluation); referenced and compared in the RouterArena paper. Useful background reading.

---

## 7. Common evaluation mistakes

| Mistake | Consequence | Fix |
|---|---|---|
| Measuring "router accuracy" vs. a single label | Ignores that several models may be good enough | Use quality retained + cost saved + under-route rate |
| Evaluating on public benchmarks only | Your traffic is different | Hold-out set from your logs |
| Ignoring follow-up turns | Overestimates quality | Slice by turn index; include context in route text |
| Using average token counts across models | Mis-estimates cost | Per-model output-length ratios |
| Trusting the LLM judge blindly | Biased labels → biased router | Human calibration set; second judge spot-checks |
| Tuning λ on the test set | Optimistic numbers | Separate validation and test splits |
