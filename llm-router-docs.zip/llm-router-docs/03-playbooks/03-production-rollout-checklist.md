# Playbook 03 — Production Rollout Checklist

A phased plan you can paste into your project tracker. Each phase has entry criteria, tasks, and exit criteria.

---

## Phase 0 — Baseline (week 0–1)

**Tasks**
- [ ] Log per request: `request_id, session_id, user/team, app, model, input_tokens, output_tokens, cost_usd, latency_ttft, latency_total, feedback (thumbs/regenerate)`.
- [ ] Dashboard: cost/day, cost/conversation, model mix, thumbs-down rate per model.
- [ ] Agree on the quality rubric and δ (playbook 01, step 0).
- [ ] Define policy floors (e.g., legal/finance/HR ≥ `general-large`), data-handling rules for router logs.
- [ ] Legal review of licenses for any router *model* you might use (Arch-Router: Katanemo license; NVIDIA classifier: NVIDIA Open Model License).

**Exit:** two weeks of baseline metrics; rubric signed off.

---

## Phase 1 — Quick win in shadow (week 1–3)

**Tasks**
- [ ] Deploy LiteLLM Auto Router (guide 01) **or** a rules + NVIDIA-classifier sidecar (guides 07/08) — shadow only.
- [ ] Your API calls the router with an 80 ms timeout, logs `routed_model`, serves with the old model.
- [ ] Sample and judge 200 shadow decisions where routed < served (playbook 02, stage 2).
- [ ] Estimate savings and quality risk.

**Exit:** projected savings ≥ target (e.g., 30%) with estimated quality retained ≥ 97%; router p95 < 50 ms; fallback rate < 0.5%.

---

## Phase 2 — Learned router (week 3–8)

**Tasks**
- [ ] Build the labeled dataset (playbook 01, steps 1–4): 3k–10k prompts × 5 models, judged.
- [ ] Validate the judge against 150–300 human labels.
- [ ] Train kNN + MLP (and optionally LLMRouter models); pick λ on validation; report on a held-out test set.
- [ ] Compare against Phase 1 router on the same test set (playbook 02, stage 1).
- [ ] Package as a container with versioned artifact (`router_version`).

**Exit:** learned router beats Phase 1 router on the cost–quality curve at the chosen operating point.

---

## Phase 3 — Online rollout (week 6–10)

**Tasks**
- [ ] Feature flags: `ROUTER_ENABLED`, `ROUTER_SHADOW`, `ROUTER_PERCENT`, `ROUTER_DEFAULT_MODEL`, `ROUTER_VERSION_PIN`.
- [ ] A/B by user: 5% → 25% → 50% → 100%, minimum one business cycle per step.
- [ ] Auto-stop guardrails wired to alerts (below).
- [ ] "Regenerate with a stronger model" button in the chatbot UI (cheap insurance + great training signal).
- [ ] Session policy live: per-user-turn routing, no downgrade within TTL, allow upgrades.

**Exit:** A/B shows cost reduction with no statistically significant quality regression on primary proxies.

---

## Phase 4 — Operate and improve (ongoing)

- [ ] Weekly judged sample per model; misroutes added to dataset.
- [ ] Monthly retrain (or on any model swap); canary new `router_version`.
- [ ] Quarterly: re-run oracle analysis; reconsider model lineup (maybe a 6th cheap model unlocks more savings, or a tier is never chosen and can be retired).
- [ ] Optional platform step: evaluate vLLM Semantic Router if you need semantic caching, PII/jailbreak filtering, and multi-app routing policy (guide 02).

---

## SLOs

| SLO | Target |
|---|---|
| Router decision latency | p95 < 50 ms, p99 < 100 ms |
| Router availability | 99.9% (fallback keeps chatbot at 100% of its own SLO) |
| Fallback rate | < 0.5% of requests |
| Quality retained (weekly judged sample) | ≥ 97% of always-best baseline |
| Under-route rate (weekly judged sample) | < 5% |

## Dashboards

1. **Money:** cost/day, cost/conversation, savings vs. baseline, model mix over time.
2. **Quality:** thumbs-down and regenerate rate by served model and by router decision reason; weekly judge scores.
3. **Router health:** decision latency percentiles, timeout/fallback rate, version in use, decisions/sec.
4. **Behavior:** top routed intents/topics, follow-up vs. first-turn decisions, session pins vs. fresh decisions.

## Alerts

| Alert | Condition | Action |
|---|---|---|
| Router slow | p95 > 80 ms for 10 min | Check GPU/CPU saturation; scale out; circuit breaker engages |
| Fallback spike | > 2% for 5 min | Page on-call; check router health/version |
| Mix shift | frontier share ± 50% vs. 7-day average | Investigate traffic change vs. router regression |
| Quality regression | thumbs-down +20% relative in treatment | Auto-reduce `ROUTER_PERCENT` to 0; investigate |
| Budget | daily spend > forecast + 25% | Raise λ temporarily / cap frontier share |

## Runbooks

**Router outage:** circuit breaker → all traffic to `ROUTER_DEFAULT_MODEL` (`general-small` or `general-large` depending on risk appetite). Restore, verify `/healthz`, re-enable gradually.

**Bad release:** set `ROUTER_VERSION_PIN` to the previous version; redeploy; compare decision diffs between versions on yesterday's traffic before trying again.

**Quality complaint on a topic:** find decisions for that topic (by embedding search on logs), add a policy floor or keyword override immediately, add examples to the dataset, retrain.

**New model added:** add it as a candidate with `allowed_models` excluding it; generate + judge it on the existing labeled set; retrain; then include it.
