# Playbook 01 — Build Your Own Learned Router (End to End, With Code)

This is the path to the **best cost/quality curve on your traffic**. It uses only open-source pieces and your existing inference API. Expect 2–6 weeks for the first production version, most of it data and evaluation.

```
 logs ─▶ 1.sample ─▶ 2.generate (5 models) ─▶ 3.judge ─▶ 4.dataset ─▶ 5.train+calibrate ─▶ 6.serve (/route) ─▶ 7.monitor+retrain
```

Requirements: Python 3.10+, `pip install openai httpx numpy scikit-learn sentence-transformers fastapi uvicorn joblib tqdm`.

All scripts read:

```bash
export INFERENCE_API_BASE=https://inference.internal.example.com/v1
export INFERENCE_API_KEY=sk-internal-...
```

---

## Step 0 — Decide what "good enough" means

Write a 1-page **quality rubric** with stakeholders: correctness, completeness, following instructions, tone/policy compliance, formatting. Decide δ: "a cheaper model is good enough if its score is within **1 point** (on 1–10) of the best model". Decide hard floors (e.g., legal/HR/finance topics never below `general-large`).

---

## Step 1 — Sample representative prompts

Goal: 3,000–10,000 prompts that look like production, PII-scrubbed. Stratify so rare-but-important categories (code, finance, long docs) are represented.

```python
# 1_sample.py — reads your chat logs (JSONL: {"conversation_id", "messages": [...], "team", "ts"})
import json, random, re, hashlib
random.seed(7)

EMAIL = re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+")
PHONE = re.compile(r"\+?\d[\d\s().-]{7,}\d")
def scrub(t: str) -> str:
    return PHONE.sub("<PHONE>", EMAIL.sub("<EMAIL>", t))

def route_text(messages: list[dict]) -> str:
    """What the router will see in production: last user ask (+ previous asks if it's a short follow-up)."""
    users = [m["content"] for m in messages if m["role"] == "user" and isinstance(m["content"], str)]
    if not users: return ""
    last = users[-1]
    return "\n".join(users[-3:]) if len(last) < 40 and len(users) > 1 else last

seen, buckets = set(), {}
for line in open("chat_logs.jsonl"):
    c = json.loads(line)
    msgs = c["messages"]
    # every user turn is a candidate routing point
    for i, m in enumerate(msgs):
        if m["role"] != "user": continue
        ctx = msgs[: i + 1]
        rt = scrub(route_text(ctx))
        h = hashlib.md5(rt.lower().encode()).hexdigest()
        if not rt or h in seen: continue
        seen.add(h)
        key = (c.get("team", "unknown"), "long" if len(rt) > 800 else "short")
        buckets.setdefault(key, []).append({"id": h, "context": [{**x, "content": scrub(x["content"])} for x in ctx[-6:]],
                                            "route_text": rt, "team": c.get("team")})

TARGET = 6000
per_bucket = max(50, TARGET // max(1, len(buckets)))
sample = [x for b in buckets.values() for x in random.sample(b, min(len(b), per_bucket))]
random.shuffle(sample)
with open("sample.jsonl", "w") as f:
    for x in sample[:TARGET]: f.write(json.dumps(x) + "\n")
print(len(sample[:TARGET]), "prompts across", len(buckets), "buckets")
```

---

## Step 2 — Generate answers from all five models

```python
# 2_generate.py
import asyncio, json, os
from openai import AsyncOpenAI
from tqdm.asyncio import tqdm

MODELS = ["fast-mini", "general-small", "general-large", "code-specialist", "reasoning-frontier"]
PRICE = {  # USD per 1M tokens (input, output) — YOUR real prices
    "fast-mini": (0.15, 0.60), "general-small": (0.50, 1.50), "general-large": (3.0, 15.0),
    "code-specialist": (2.5, 10.0), "reasoning-frontier": (15.0, 60.0),
}
client = AsyncOpenAI(base_url=os.environ["INFERENCE_API_BASE"], api_key=os.environ["INFERENCE_API_KEY"])
sem = asyncio.Semaphore(16)  # respect your rate limits

async def run(item, model):
    async with sem:
        try:
            r = await client.chat.completions.create(model=model, messages=item["context"],
                                                     max_tokens=1500, temperature=0.2)
            u = r.usage
            cost = (u.prompt_tokens * PRICE[model][0] + u.completion_tokens * PRICE[model][1]) / 1e6
            return {"model": model, "answer": r.choices[0].message.content,
                    "in_tok": u.prompt_tokens, "out_tok": u.completion_tokens, "cost": cost}
        except Exception as e:
            return {"model": model, "answer": None, "error": str(e), "cost": None}

async def main():
    items = [json.loads(l) for l in open("sample.jsonl")]
    with open("generations.jsonl", "w") as f:
        for item in tqdm(items):
            outs = await asyncio.gather(*(run(item, m) for m in MODELS))
            f.write(json.dumps({**item, "outputs": outs}) + "\n")

asyncio.run(main())
```

Cost control: start with 1,000 prompts to validate the pipeline; most of the spend is `reasoning-frontier`.

---

## Step 3 — Judge every answer (LLM-as-judge)

Absolute 1–10 scores per answer (no position bias), by your strongest model, with a rubric. Validate against humans on 150–300 items before trusting it.

```python
# 3_judge.py
import asyncio, json, os, re
from openai import AsyncOpenAI
from tqdm.asyncio import tqdm

JUDGE = "reasoning-frontier"
client = AsyncOpenAI(base_url=os.environ["INFERENCE_API_BASE"], api_key=os.environ["INFERENCE_API_KEY"])
sem = asyncio.Semaphore(16)

RUBRIC = """You are grading an AI assistant's answer for an internal company chatbot.
Score 1-10 using this rubric:
- Correctness and factual accuracy (most important)
- Completeness relative to what the user asked
- Following explicit instructions and constraints
- Clarity and appropriate format/length
- Safety and policy compliance
Do not reward verbosity. A short, correct, complete answer can score 10.
Return ONLY JSON: {"score": <int 1-10>, "reason": "<one sentence>"}"""

def fmt(ctx):
    return "\n".join(f"{m['role'].upper()}: {m['content']}" for m in ctx)

async def grade(ctx, answer):
    async with sem:
        r = await client.chat.completions.create(model=JUDGE, temperature=0, max_tokens=200, messages=[
            {"role": "system", "content": RUBRIC},
            {"role": "user", "content": f"CONVERSATION:\n{fmt(ctx)}\n\nASSISTANT ANSWER TO GRADE:\n{answer}"}])
        txt = r.choices[0].message.content
        m = re.search(r"\{.*\}", txt, re.S)
        try:
            return int(json.loads(m.group(0))["score"])
        except Exception:
            return None

async def main():
    with open("judged.jsonl", "w") as f:
        for line in tqdm(list(open("generations.jsonl"))):
            row = json.loads(line)
            scores = await asyncio.gather(*(grade(row["context"], o["answer"]) if o.get("answer") else asyncio.sleep(0, None)
                                            for o in row["outputs"]))
            for o, s in zip(row["outputs"], scores): o["score"] = s
            f.write(json.dumps(row) + "\n")

asyncio.run(main())
```

**Judge hygiene:**

- Self-preference bias: the judge may favor its own family. Spot-check with a second judge model on 10% of items.
- Calibrate: compute agreement with human labels (Spearman ρ, and accuracy of "good enough" decisions). Target ρ > 0.6, decision agreement > 80%.
- For code, add execution-based checks where possible (run tests, lint SQL).

---

## Step 4 — Build the training dataset

```python
# 4_dataset.py
import json
MODELS = ["fast-mini", "general-small", "general-large", "code-specialist", "reasoning-frontier"]
DELTA = 1   # "good enough" = within 1 point of best

with open("dataset.jsonl", "w") as f:
    for line in open("judged.jsonl"):
        r = json.loads(line)
        outs = {o["model"]: o for o in r["outputs"]}
        if any(outs[m].get("score") is None or outs[m].get("cost") is None for m in MODELS):
            continue
        scores = {m: outs[m]["score"] for m in MODELS}
        costs = {m: outs[m]["cost"] for m in MODELS}
        best = max(scores.values())
        ok = [m for m in MODELS if scores[m] >= best - DELTA]
        oracle = min(ok, key=lambda m: costs[m])            # cheapest good-enough model
        f.write(json.dumps({"id": r["id"], "route_text": r["route_text"], "team": r.get("team"),
                            "scores": scores, "costs": costs, "oracle": oracle}) + "\n")
```

Look at the **oracle distribution** before training — it's your savings ceiling:

```python
import json, collections
rows = [json.loads(l) for l in open("dataset.jsonl")]
print(collections.Counter(r["oracle"] for r in rows))
base = sum(r["costs"]["reasoning-frontier"] for r in rows)
orac = sum(r["costs"][r["oracle"]] for r in rows)
print(f"oracle saves {1 - orac/base:.1%} vs always-frontier")
```

---

## Step 5 — Train and calibrate

Two complementary learners on sentence embeddings:

- **kNN regressor** — predicts each model's score as the weighted average over similar past prompts. Strong, interpretable, updates instantly when you add data.
- **MLP regressor** — smoother generalization with more data.

Then choose **λ** (cost sensitivity) on validation data to hit your target.

```python
# 5_train.py
import json, joblib, numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsRegressor
from sklearn.neural_network import MLPRegressor

MODELS = ["fast-mini", "general-small", "general-large", "code-specialist", "reasoning-frontier"]
ENCODER = "BAAI/bge-small-en-v1.5"        # multilingual traffic? use "intfloat/multilingual-e5-small"

rows = [json.loads(l) for l in open("dataset.jsonl")]
texts = [r["route_text"] for r in rows]
Q = np.array([[r["scores"][m] for m in MODELS] for r in rows], dtype=float) / 10.0
C = np.array([[r["costs"][m] for m in MODELS] for r in rows], dtype=float)

enc = SentenceTransformer(ENCODER)
X = enc.encode(texts, normalize_embeddings=True, batch_size=64, show_progress_bar=True)

Xtr, Xva, Qtr, Qva, Ctr, Cva = train_test_split(X, Q, C, test_size=0.2, random_state=0)

knn = KNeighborsRegressor(n_neighbors=25, weights="distance", metric="cosine").fit(Xtr, Qtr)
mlp = MLPRegressor(hidden_layer_sizes=(512, 128), early_stopping=True, max_iter=500,
                   random_state=0).fit(Xtr, Qtr)

def predict(X_):                       # simple ensemble
    return 0.5 * knn.predict(X_) + 0.5 * mlp.predict(X_)

cost_vec = Ctr.mean(axis=0)            # avg $ per request per model
cost_norm = cost_vec / cost_vec.max()  # 0..1

def simulate(Qhat, Q_, C_, lam):
    pick = np.argmax(Qhat - lam * cost_norm[None, :], axis=1)
    idx = np.arange(len(pick))
    return Q_[idx, pick].mean(), C_[idx, pick].sum(), np.bincount(pick, minlength=len(MODELS)) / len(pick)

Qhat = predict(Xva)
best_q = Qva[:, MODELS.index("reasoning-frontier")].mean()
best_c = Cva[:, MODELS.index("reasoning-frontier")].sum()
print(f"always-frontier: quality={best_q:.3f} cost=${best_c:.2f}")

results = []
for lam in np.linspace(0, 1.0, 41):
    q, c, dist = simulate(Qhat, Qva, Cva, lam)
    results.append((lam, q, c, dist))
    print(f"λ={lam:.3f} quality={q:.3f} ({q/best_q:.1%} of frontier) cost=${c:.2f} ({1-c/best_c:.1%} saved) "
          f"mix={dict(zip(MODELS, np.round(dist, 2)))}")

# Pick the cheapest λ that keeps ≥ 97% of frontier quality (business choice)
TARGET = 0.97
ok = [r for r in results if r[1] >= TARGET * best_q]
lam_star = max(ok, key=lambda r: r[0])[0] if ok else 0.0
print("chosen λ =", lam_star)

joblib.dump({"knn": knn, "mlp": mlp, "models": MODELS, "encoder": ENCODER,
             "cost_norm": cost_norm, "lambda": float(lam_star), "version": "learned-r1"}, "router.joblib")
```

**Improvements once the basics work:**

- Add **features** beyond the embedding: NVIDIA classifier dimensions (guide 08), length, code markers, team one-hot, turn index. Concatenate to `X`.
- Predict **cost per request** too (output length varies by model and prompt) instead of using the mean.
- Try LLMRouter's `mlprouter`, `graphrouter`, `routerdc` on the same data and compare on the same validation split (guide 06).
- Per-segment λ: lower λ for high-stakes teams.

---

## Step 6 — Serve the decision service (`/route`)

Layered decision: **hard rules → learned scorer → policy (λ) → session guard → fallback**.

```python
# router_service.py
import re, time, joblib, numpy as np
from fastapi import FastAPI
from pydantic import BaseModel
from sentence_transformers import SentenceTransformer

A = joblib.load("router.joblib")
MODELS, LAM, COSTN = A["models"], A["lambda"], A["cost_norm"]
enc = SentenceTransformer(A["encoder"])
ORDER = {m: i for i, m in enumerate(["fast-mini", "general-small", "general-large", "code-specialist", "reasoning-frontier"])}
DEFAULT = "general-small"

GREETING = re.compile(r"^\s*(hi|hello|hey|thanks|thank you|merci|ok|okay)[\s!.?]*$", re.I)
FLOOR_BY_TEAM = {"legal": "general-large", "finance": "general-large"}   # policy floors
SESSION: dict[str, tuple[str, float]] = {}      # use Redis in production
SESSION_TTL = 1800

app = FastAPI()

class RouteReq(BaseModel):
    session_id: str | None = None
    messages: list[dict]
    metadata: dict = {}
    constraints: dict = {}

def route_text(messages):
    users = [m["content"] for m in messages if m.get("role") == "user" and isinstance(m.get("content"), str)]
    if not users: return ""
    last = users[-1]
    return "\n".join(users[-3:]) if len(last) < 40 and len(users) > 1 else last

def rank(m: str) -> int:
    return ORDER.get(m, 1)

@app.post("/route")
def route(req: RouteReq):
    t0 = time.perf_counter()
    text = route_text(req.messages)
    allowed = set(req.constraints.get("allowed_models") or MODELS)
    reason = []

    if GREETING.match(text or ""):
        model, reason = "fast-mini", ["rule:greeting"]
    else:
        x = enc.encode([text], normalize_embeddings=True)
        qhat = 0.5 * A["knn"].predict(x)[0] + 0.5 * A["mlp"].predict(x)[0]
        util = qhat - LAM * COSTN
        for i, m in enumerate(MODELS):
            if m not in allowed: util[i] = -np.inf
        model = MODELS[int(np.argmax(util))]
        reason.append(f"learned:λ={LAM:.2f}")

    floor = FLOOR_BY_TEAM.get(req.metadata.get("team", ""))
    if floor and rank(model) < rank(floor) and model != "code-specialist":
        model, reason = floor, reason + [f"floor:{floor}"]

    # Session guard: no downgrade within TTL (protects cache + consistency); upgrades allowed
    if req.session_id:
        prev = SESSION.get(req.session_id)
        if prev and time.time() - prev[1] < SESSION_TTL and rank(model) < rank(prev[0]):
            model, reason = prev[0], reason + ["session:no-downgrade"]
        SESSION[req.session_id] = (model, time.time())

    if model not in allowed:
        model, reason = DEFAULT, reason + ["fallback:not-allowed"]
    return {"model": model, "reason": " → ".join(reason), "router_version": A["version"],
            "latency_ms": round((time.perf_counter() - t0) * 1000, 1)}

@app.get("/healthz")
def healthz():
    enc.encode(["ping"]); return {"ok": True, "version": A["version"]}
```

```bash
uvicorn router_service:app --host 0.0.0.0 --port 8080 --workers 2
curl -s localhost:8080/route -H 'content-type: application/json' \
  -d '{"session_id":"s1","messages":[{"role":"user","content":"Write a SQL query for monthly churn by plan"}],"metadata":{"team":"data"}}'
```

**Dockerfile:**

```dockerfile
FROM python:3.11-slim
WORKDIR /app
RUN pip install --no-cache-dir fastapi uvicorn sentence-transformers scikit-learn joblib numpy
# Pre-download the encoder at build time (no network at runtime)
RUN python -c "from sentence_transformers import SentenceTransformer as S; S('BAAI/bge-small-en-v1.5')"
COPY router.joblib router_service.py ./
EXPOSE 8080
CMD ["uvicorn", "router_service:app", "--host", "0.0.0.0", "--port", "8080", "--workers", "2"]
```

Wire it into your API with the contract and code in [`../01-fundamentals/02-integration-architecture.md`](../01-fundamentals/02-integration-architecture.md), or into LiteLLM as a custom classifier plugin (guide 01).

---

## Step 7 — Monitor and retrain

- **Daily:** model mix %, cost/request, router latency p95, fallback rate.
- **Weekly:** sample 200 routed conversations stratified by chosen model; judge them; plot quality per model vs. last week; look for misroutes (cheap model + low score) and add them to the dataset.
- **Monthly or on model change:** regenerate answers for a fresh sample, re-judge, retrain, re-pick λ, canary release (`router_version` bump).
- **kNN advantage:** you can append new labeled examples to the kNN index without retraining the MLP — useful for quick fixes.

Next: [`02-evaluation-and-benchmarking.md`](02-evaluation-and-benchmarking.md).
