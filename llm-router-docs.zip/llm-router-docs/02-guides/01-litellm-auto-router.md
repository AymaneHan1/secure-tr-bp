# Guide 01 — LiteLLM Auto Router (Complexity / Semantic / Adaptive)

## At a glance

| | |
|---|---|
| **What** | A routing alias inside the LiteLLM proxy/SDK that classifies each request into a tier and forwards it to that tier's model(s) |
| **License** | MIT core; the `enterprise/` folder is under a separate commercial license ✅ |
| **Repo / docs** | https://github.com/BerriAI/litellm · https://docs.litellm.ai/docs/proxy/auto_routing |
| **Status** | Auto Routing is **[Beta]**; ships from v1.94.x; custom classifier plugins from v1.99.x; compression per hop from v1.101.0 ✅ |
| **Routing families** | Heuristic scorer, LLM classifier, keyword + semantic keyword rules, custom Python classifier, Thompson sampling within tier pools |
| **Integration patterns** | B (in front), C (behind), D (Python SDK), A partially (test-routing preview endpoint) |
| **Best for** | Fastest path to a working, observable router with no training |

---

## 1. How it works

1. Client calls `model: "smart-router"` (a router alias).
2. LiteLLM extracts the **last real human ask** (skipping tool output and `<system-reminder>` blocks) and the latest system prompt.
3. **Keyword rules** run first (deterministic; if several match, the highest tier wins).
4. The **classifier** assigns a tier — `SIMPLE`, `MEDIUM`, `COMPLEX`, `REASONING`:
   - **Heuristic (default):** zero API calls, sub-millisecond. Weighted dimensions: `tokenCount`, `codePresence`, `reasoningMarkers`, `technicalTerms`, `simpleIndicators`, `multiStepPatterns`, `questionComplexity`. Two or more reasoning markers force `REASONING`.
   - **LLM classifier:** a small fast model with structured output; can see up to N prior turns (default 3 user turns, 8,000 chars budget); falls back to the heuristic on timeout/error.
   - **Custom plugin:** your Python `async classify(context)` returns a tier (or `None` to defer).
5. The tier maps to a **single model**, a **random pool**, or an **adaptive pool** (Thompson sampling with feedback).
6. Optional: **session affinity** (pin first-turn model), **context-window escalation**, **reasoning-effort ladders**.
7. Every decision logs a greppable line with `cause=` (scorer, literal, semantic, session_pin, LLM, plugin) and a **savings estimate** vs. a derived baseline (the most expensive model in the hardest configured tier).

> The older embedding-based "Semantic Auto Router" (`auto_router/<name>` with utterances) is **deprecated** but still works; new deployments should use `auto_router/complexity_router`.

---

## 2. Prerequisites

- Docker (or Python 3.10+ for `pip install 'litellm[proxy]'`).
- Postgres if you want spend logs, virtual keys, the UI, and **savings reporting** (strongly recommended).
- Redis if you run multiple proxy replicas (shared cache/rate limits/affinity state).
- Your inference API reachable from the proxy, OpenAI-compatible.
- Per-token prices for your 5 aliases (LiteLLM can't know prices of custom aliases).

**Download / install**

```bash
# Container (recommended). Pin an explicit version tag in production instead of a moving tag.
docker pull ghcr.io/berriai/litellm:main-stable
# All tags: https://github.com/berriai/litellm/pkgs/container/litellm

# Or Python
pip install 'litellm[proxy]'
```

> ⚠️ Pin versions and check LiteLLM's security advisories before upgrading. A community setup guide (techsy.io, June 2026) recommends v1.83+ and avoiding 1.82.7 and 1.82.8. Auto Routing itself needs ≥ 1.94.x.

---

## 3. Configure — five models via your inference API

`config.yaml`:

```yaml
model_list:
  # ── Your five models, all served by YOUR inference API (OpenAI-compatible) ──
  - model_name: fast-mini
    litellm_params:
      model: openai/fast-mini                 # "openai/" = OpenAI-compatible protocol
      api_base: os.environ/INFERENCE_API_BASE
      api_key: os.environ/INFERENCE_API_KEY
      input_cost_per_token: 0.00000015        # ⚠️ your real prices (USD/token)
      output_cost_per_token: 0.0000006
    model_info:
      max_input_tokens: 128000
      supports_vision: false

  - model_name: general-small
    litellm_params:
      model: openai/general-small
      api_base: os.environ/INFERENCE_API_BASE
      api_key: os.environ/INFERENCE_API_KEY
      input_cost_per_token: 0.0000005
      output_cost_per_token: 0.0000015
    model_info: {max_input_tokens: 128000}

  - model_name: general-large
    litellm_params:
      model: openai/general-large
      api_base: os.environ/INFERENCE_API_BASE
      api_key: os.environ/INFERENCE_API_KEY
      input_cost_per_token: 0.000003
      output_cost_per_token: 0.000015
    model_info: {max_input_tokens: 200000}

  - model_name: code-specialist
    litellm_params:
      model: openai/code-specialist
      api_base: os.environ/INFERENCE_API_BASE
      api_key: os.environ/INFERENCE_API_KEY
      input_cost_per_token: 0.0000025
      output_cost_per_token: 0.00001
    model_info: {max_input_tokens: 200000}

  - model_name: reasoning-frontier
    litellm_params:
      model: openai/reasoning-frontier
      api_base: os.environ/INFERENCE_API_BASE
      api_key: os.environ/INFERENCE_API_KEY
      input_cost_per_token: 0.000015
      output_cost_per_token: 0.00006
    model_info: {max_input_tokens: 200000}

  # ── The router alias your clients call ──
  - model_name: smart-router
    litellm_params:
      model: auto_router/complexity_router
      drop_params: true
      complexity_router_config:
        tiers:
          SIMPLE:    fast-mini
          MEDIUM:    general-small
          COMPLEX:   general-large
          REASONING: reasoning-frontier

        # Deterministic overrides, evaluated before the scorer (highest tier wins)
        keyword_tier_rules:
          - keywords: ["hi", "hello", "thanks", "thank you"]
            tier: SIMPLE
          - keywords: ["prove", "derive", "optimize the algorithm", "root cause"]
            tier: REASONING
        semantic_keyword_matching: false        # enable later with an in-house embedding model

        # Domain vocabulary the default scorer doesn't know
        custom_technical_keywords: [kafka, kubernetes, terraform, snowflake, sap, salesforce]

        # Multi-turn behavior for a chatbot
        classification_mode: user_turn          # classify new user asks; carry decision through continuation turns
        session_affinity: true                  # pin a session to its first-turn model (cache-friendly)
        session_affinity_ttl_seconds: 1800

        enable_context_window_escalation: true  # move up if the prompt provably doesn't fit
        return_raw_model_name: true             # response "model" = the model actually used
      complexity_router_default_model: general-small
    model_info:
      max_input_tokens: 128000                  # advisory; declare the smallest window you route to

router_settings:
  enable_pre_call_checks: true                  # needed for context-window enforcement
  optional_pre_call_checks: ["session_affinity", "prompt_caching"]

general_settings:
  master_key: os.environ/LITELLM_MASTER_KEY
  database_url: os.environ/DATABASE_URL          # spend logs + savings dashboard
```

### Where does `code-specialist` go?

The four built-in tiers are about **difficulty**, while `code-specialist` is about **task**. Options:

1. **Simplest:** make `COMPLEX` a pool and let the adaptive bandit learn: `COMPLEX: ["general-large", "code-specialist"]` with `adaptive: true` — works only if you feed back quality signals. Not ideal for a pure task split.
2. **Recommended:** use a **custom classifier plugin** (below) that returns `COMPLEX` for analysis and a **custom tier label** for code. ⚠️ Defining custom tiers via `tier_definitions` is an Enterprise feature; built-in tiers + plugin are open source.
3. **Routing plugins** (v1.92.x+): a plugin can narrow `candidate_models` (e.g., when code is detected, restrict to `code-specialist`) before the tier pick. ⚠️ Read https://docs.litellm.ai/docs/routing_plugins for the current interface.
4. **Two aliases:** your API (or UI) sends obviously-code requests to a `code-router` alias whose tiers are `general-small → code-specialist → reasoning-frontier`.

### Upgrade path: LLM classifier (more accurate, small cost)

```yaml
      complexity_router_config:
        classifier_type: llm
        classifier_llm_config:
          model: fast-mini            # a cheap model from YOUR API grades complexity
          timeout_ms: 1500
        classifier_fallback: heuristic
        classifier_context_window_size: 3
        classifier_context_include_assistant_turns: true   # fixes the "yes" problem
        classifier_context_per_turn_chars: 300
```

The classifier's own cost is recorded (`classifier_cost`) and deducted from reported savings.

### Upgrade path: plug in your own trained router

```yaml
      complexity_router_config:
        classifier_type: custom
        classifier_plugin: classifiers.learned_router   # file classifiers.py next to config.yaml
        classifier_plugin_timeout_ms: 100
        classifier_fallback: heuristic
```

```python
# classifiers.py  (config file only — cannot be set via UI/API)
import httpx
from litellm.types.router import RoutingContext

TIER_FOR_MODEL = {
    "fast-mini": "SIMPLE", "general-small": "MEDIUM",
    "general-large": "COMPLEX", "reasoning-frontier": "REASONING",
}

class LearnedRouter:
    def __init__(self):
        self.http = httpx.AsyncClient(timeout=0.08)

    async def classify(self, context: RoutingContext) -> str | None:
        try:
            r = await self.http.post("http://router-sidecar:8080/route",
                                     json={"messages": context.structured_messages,
                                           "metadata": context.metadata})
            model = r.json().get("model")
            return TIER_FOR_MODEL.get(model)      # None → classifier_fallback decides
        except Exception:
            return None                           # degrade, never fail the request

learned_router = LearnedRouter()
```

Your sidecar is built in [`../03-playbooks/01-build-your-own-router.md`](../03-playbooks/01-build-your-own-router.md).

---

## 4. Run locally

```bash
export INFERENCE_API_BASE=https://inference.internal.example.com/v1
export INFERENCE_API_KEY=sk-internal-...
export LITELLM_MASTER_KEY=sk-litellm-$(openssl rand -hex 16)

docker run --rm -p 4000:4000 \
  -v $(pwd)/config.yaml:/app/config.yaml \
  -e INFERENCE_API_BASE -e INFERENCE_API_KEY -e LITELLM_MASTER_KEY \
  ghcr.io/berriai/litellm:main-stable \
  --config /app/config.yaml --detailed_debug
```

Test:

```bash
curl -s http://localhost:4000/v1/chat/completions \
  -H "Authorization: Bearer $LITELLM_MASTER_KEY" -H "Content-Type: application/json" \
  -d '{"model":"smart-router","messages":[{"role":"user","content":"hi!"}]}' | jq .model
# → "fast-mini"

curl -s http://localhost:4000/v1/chat/completions \
  -H "Authorization: Bearer $LITELLM_MASTER_KEY" -H "Content-Type: application/json" \
  -d '{"model":"smart-router","messages":[{"role":"user","content":"Think step by step and analyze the trade-offs of event sourcing vs CRUD for our billing system, then propose a migration plan."}]}' | jq .model
# → "reasoning-frontier" (two reasoning markers)
```

Check the decision log in container output:

```
ComplexityRouter: routing decision cause=complexity_scorer, tier=SIMPLE, score=-0.150, signals=['short (2 tokens)', ...], routed_model=fast-mini
```

**Agent-assisted setup:** LiteLLM publishes a setup skill for coding agents: `curl -fsSL https://docs.litellm.ai/skills/auto-router` (it reads your proxy's models and proposes tier mappings). There's also a local CLI preview: https://docs.litellm.ai/docs/learn/autorouter_cli.

**UI:** Models + Endpoints → Add Model → *Auto Router* tab → "Configure automatically" or templates. **Test Routing** classifies without calling the completion model.

---

## 5. Use it from your ecosystem

**Pattern B (clients → LiteLLM → your API):** point clients' OpenAI SDK at `http://litellm:4000` with `model="smart-router"`.

**Pattern C (your API → LiteLLM):** register LiteLLM in your API as provider `auto`; ensure LiteLLM calls an internal path of your API that doesn't route back to `auto`.

**Shadow / decision preview:** `POST /auto_router/test_routing` classifies a request without sending the completion (still incurs classifier/embedding cost if those are LLM-based). Use it to log "what the router would do" for a week. ⚠️ Check the docs for the exact request body (it accepts a `default_model` field for the preview).

**Reading which model served:** response header `x-litellm-model-id`, or body `model` when `return_raw_model_name: true`.

**Sessions:** send `metadata: {"session_id": "<conversation id>"}` so affinity works:

```python
from openai import OpenAI
client = OpenAI(base_url="http://litellm:4000", api_key=LITELLM_KEY)
resp = client.chat.completions.create(
    model="smart-router",
    messages=messages,
    extra_body={"metadata": {"session_id": conversation_id}},
)
print(resp.model)   # actual tier model
```

---

## 6. Deploy to production

### Docker Compose (single host, with Postgres + Redis)

```yaml
services:
  litellm:
    image: ghcr.io/berriai/litellm:main-stable   # pin a version tag
    command: ["--config", "/app/config.yaml", "--num_workers", "4"]
    ports: ["4000:4000"]
    volumes:
      - ./config.yaml:/app/config.yaml:ro
      - ./classifiers.py:/app/classifiers.py:ro
    environment:
      INFERENCE_API_BASE: ${INFERENCE_API_BASE}
      INFERENCE_API_KEY: ${INFERENCE_API_KEY}
      LITELLM_MASTER_KEY: ${LITELLM_MASTER_KEY}
      DATABASE_URL: postgresql://litellm:${PG_PASS}@postgres:5432/litellm
      REDIS_HOST: redis
      REDIS_PORT: "6379"
    depends_on: [postgres, redis]
    restart: always
  postgres:
    image: postgres:16
    environment: {POSTGRES_USER: litellm, POSTGRES_PASSWORD: "${PG_PASS}", POSTGRES_DB: litellm}
    volumes: [pgdata:/var/lib/postgresql/data]
  redis:
    image: redis:7
volumes: {pgdata: {}}
```

### Kubernetes

- LiteLLM provides a Helm chart (see https://docs.litellm.ai — "Deploy" / Helm section). Mount `config.yaml` (and `classifiers.py`) from a ConfigMap, secrets from a Secret.
- ≥ 2 replicas behind a Service; Redis for shared state; managed Postgres.
- Readiness/liveness: `/health/readiness`, `/health/liveliness` ⚠️ verify paths for your version.
- HPA on CPU; the heuristic classifier is CPU-trivial.

### Observability

- Decision logs (`cause=`), spend logs, **Cost Optimization** page ("Auto-router savings"), API `GET /user/daily/activity` (`total_autorouter_savings_spend`).
- Daily rollup tables carry `autorouter_savings_spend` and cache token columns.
- Prometheus metrics exist; some are Enterprise-gated in LiteLLM — check your version.

---

## 7. Tuning playbook

1. **Week 1 — shadow:** log tier decisions on real traffic; sample 200 per tier; have reviewers (or an LLM judge) mark "too low / OK / too high".
2. **Adjust the scorer:** `tier_boundaries` (defaults: `simple_medium 0.15`, `medium_complex 0.35`, `complex_reasoning 0.60`), `token_thresholds`, `dimension_weights`, and `custom_technical_keywords`.
3. **Add keyword overrides** for known high-stakes topics (legal/HR/finance → at least `COMPLEX`).
4. **Turn on the LLM classifier** if heuristics plateau; include assistant turns.
5. **Use effort ladders** before jumping models: several aliases of the same model at different `reasoning_effort` as rungs (cheaper than switching to a frontier model).
6. **Graduate to your own learned classifier** via `classifier_type: custom`.

---

## 8. Gotchas

- **Beta:** config keys can change between releases — pin versions, read the feature history page.
- `session_affinity` default changed from `true` to `false` at some point; set it explicitly.
- Two different settings share the name `session_affinity` (router config vs. `optional_pre_call_checks`) — read the docs section "Session affinity pins the model name".
- Router aliases report `0.0` costs in `/model_group/info` — spend is still tracked on the tier model.
- Claude Code/Claude Desktop discover gateway models only if the name contains `claude` or `anthropic` (not relevant for your chatbot, relevant if devs reuse the gateway).
- Enterprise-only: SSO beyond 5 users, many built-in guardrails, custom classifier rubric replacement/`tier_definitions`.

---

## 9. Official guides & links

- Auto Routing (current): https://docs.litellm.ai/docs/proxy/auto_routing
- Semantic Auto Router (deprecated): https://docs.litellm.ai/docs/proxy/auto_routing_semantic
- Routing plugins: https://docs.litellm.ai/docs/routing_plugins
- Local CLI preview (`lite autoroute`): https://docs.litellm.ai/docs/learn/autorouter_cli
- Auto Router feature discussion: https://github.com/BerriAI/litellm/discussions/32168
- Docker images: https://github.com/berriai/litellm/pkgs/container/litellm
- Enterprise vs. open source licensing note: https://github.com/BerriAI/litellm/discussions/2023
- Full docs index (LLM-friendly): https://docs.litellm.ai/llms.txt
