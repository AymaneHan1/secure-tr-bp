# Guide 05 — RouteLLM (LMSYS)

## At a glance

| | |
|---|---|
| **What** | A framework for **serving and evaluating** learned routers between a **strong** and a **weak** model, with pretrained routers |
| **License** | Apache-2.0 ✅ |
| **Repo / paper** | https://github.com/lm-sys/RouteLLM · https://arxiv.org/abs/2406.18665 · blog https://lmsys.org/blog/2024-07-01-routellm/ |
| **Status** | Research-grade, stable, slow-moving (routers trained 2024 on GPT-4-1106 vs. Mixtral-8x7B; authors report they generalize to other pairs) |
| **Routers** | `mf` (matrix factorization, recommended), `sw_ranking` (similarity-weighted Elo), `bert` (BERT classifier), `causal_llm` (LLM classifier), `random` |
| **Integration patterns** | A (Python), B/C (OpenAI-compatible server), D (embedded) |
| **Best for** | A proven difficulty score; two-model setups; a baseline to beat |

Published results 📊: on MT-Bench, `mf` reached 95% of GPT-4 performance with 26% GPT-4 calls (~48% cheaper than random); trained with GPT-4-judge-augmented data, only 14% GPT-4 calls (~75% cheaper than random).

---

## 1. How it works

Each router computes **P(strong model's answer beats weak model's answer | prompt)** — the *strong win rate*. If it exceeds a **cost threshold**, the request goes to the strong model.

- Training data: human preference battles from Chatbot Arena, augmented with GPT-4-as-judge labels.
- The threshold is chosen by **calibration**: "what threshold sends X% of my traffic to strong?"
- Request syntax encodes router + threshold in the model name: `router-mf-0.11593`.

### Using RouteLLM with five models

RouteLLM is two-model, but the win-rate is a **continuous difficulty score** in [0, 1]. Two good ways to use it with five models:

1. **Multi-threshold tiering:** compute the score once and bucket it with 4 thresholds calibrated on your traffic:
   `score < t1 → fast-mini`, `< t2 → general-small`, `< t3 → general-large`, else `reasoning-frontier`. Use a separate rule/intent signal for `code-specialist`.
2. **Cascade of pairs:** route `fast-mini` vs. `general-large` first; if "strong", route `general-large` vs. `reasoning-frontier`.

Option 1 is simpler, faster (one scoring pass), and what the sidecar below implements.

---

## 2. Install

```bash
pip install "routellm[serve,eval]"
# or from source
git clone https://github.com/lm-sys/RouteLLM.git && cd RouteLLM && pip install -e ".[serve,eval]"
```

**Embedding dependency ✅:** the `mf` and `sw_ranking` routers call OpenAI embeddings and currently require `OPENAI_API_KEY` regardless of your model pair. For in-house-only deployments:

- prefer the **`bert`** or **`causal_llm`** routers (local checkpoints from Hugging Face), **or**
- point the OpenAI client at your API (`OPENAI_BASE_URL`) **only if** it serves the *same* embedding model the router was trained with — the MF weights are tied to that embedding space. Swapping the embedding model requires retraining.

Pretrained artifacts live under https://huggingface.co/routellm (and datasets under https://huggingface.co/lmsys). `config.example.yaml` in the repo maps each router to its checkpoint (e.g., `mf → routellm/mf_gpt4_augmented`, `bert → routellm/bert_gpt4_augmented`, `causal_llm → routellm/causal_llm_gpt4_augmented`) ⚠️ verify names in the file.

---

## 3. Quick start (two models from your API)

**Python controller (drop-in for the OpenAI client):**

```python
import os
from routellm.controller import Controller

os.environ["OPENAI_API_KEY"] = os.environ["INFERENCE_API_KEY"]   # used by the OpenAI-compatible calls

client = Controller(
    routers=["bert"],                               # in-house friendly
    strong_model="openai/reasoning-frontier",       # "openai/" prefix = OpenAI-compatible endpoint
    weak_model="openai/general-small",
    config={"bert": {"checkpoint_path": "routellm/bert_gpt4_augmented"}},
    # ⚠️ For a custom base URL, the README documents --base-url/--api-key on the server;
    #    check Controller's signature for api_base/api_key in your installed version.
)

resp = client.chat.completions.create(
    model="router-bert-0.3",                        # router + threshold
    messages=[{"role": "user", "content": "Hello!"}],
)
```

**OpenAI-compatible server:**

```bash
python -m routellm.openai_server \
  --routers bert mf \
  --strong-model openai/reasoning-frontier \
  --weak-model openai/general-small \
  --base-url "$INFERENCE_API_BASE" --api-key "$INFERENCE_API_KEY" \
  --config config.example.yaml
# → Uvicorn on http://0.0.0.0:6060 ; clients call model="router-bert-0.3"
```

Demo chat to watch routing: `python -m examples.router_chat --router mf --threshold 0.11593`.

---

## 4. Calibrate thresholds on YOUR traffic

The built-in calibration uses the public Chatbot Arena dataset:

```bash
python -m routellm.calibrate_threshold --task calibrate --routers mf --strong-model-pct 0.5 --config config.example.yaml
# For 50.0% strong model calls for mf, threshold = 0.11593
```

The authors stress: the actual % will differ on your traffic — **calibrate on a sample that resembles your queries**. Do it yourself in a few lines:

```python
# calibrate.py — compute win-rate scores on a sample of YOUR prompts, then pick quantiles
import json, numpy as np
from routellm.controller import Controller

ctrl = Controller(routers=["bert"], strong_model="openai/x", weak_model="openai/y",
                  config={"bert": {"checkpoint_path": "routellm/bert_gpt4_augmented"}})
router = ctrl.routers["bert"]                       # ⚠️ attribute name may differ by version

prompts = [json.loads(l)["prompt"] for l in open("sample_prompts.jsonl")]   # 2–5k real prompts
scores = np.array([router.calculate_strong_win_rate(p) for p in prompts])

# Target distribution across your four difficulty tiers (tune to your budget)
target = {"fast-mini": 0.35, "general-small": 0.35, "general-large": 0.20, "reasoning-frontier": 0.10}
cum = np.cumsum(list(target.values()))[:-1]          # 0.35, 0.70, 0.90
thresholds = np.quantile(scores, cum).tolist()
print("thresholds t1,t2,t3 =", thresholds)
json.dump({"router": "bert", "thresholds": thresholds, "tiers": list(target)}, open("tiers.json", "w"))
```

---

## 5. Decision-only sidecar (Pattern A) with 5 tiers

```python
# routellm_sidecar.py — FastAPI service implementing the /route contract
import json, re, time
from fastapi import FastAPI
from pydantic import BaseModel
from routellm.controller import Controller

cfg = json.load(open("tiers.json"))
ctrl = Controller(routers=[cfg["router"]], strong_model="openai/x", weak_model="openai/y",
                  config={"bert": {"checkpoint_path": "routellm/bert_gpt4_augmented"}})
router = ctrl.routers[cfg["router"]]                # ⚠️ verify attribute
T, TIERS = cfg["thresholds"], cfg["tiers"]
CODE = re.compile(r"```|\bdef |\bclass |\bSELECT\b|\bstack ?trace\b|\bTraceback\b|\bregex\b", re.I)

app = FastAPI()

class RouteReq(BaseModel):
    messages: list[dict]
    metadata: dict = {}

@app.post("/route")
def route(req: RouteReq):
    t0 = time.perf_counter()
    user_turns = [m["content"] for m in req.messages if m.get("role") == "user" and isinstance(m.get("content"), str)]
    prompt = user_turns[-1] if user_turns else ""
    if len(prompt) < 40 and len(user_turns) > 1:      # short follow-up ("yes", "do it"): use more context
        prompt = "\n".join(user_turns[-3:])
    s = float(router.calculate_strong_win_rate(prompt))
    tier = TIERS[sum(s >= t for t in T)]
    model = "code-specialist" if CODE.search(prompt) and tier != "fast-mini" else tier
    return {"model": model, "confidence": s, "reason": f"routellm:{cfg['router']} score={s:.3f}",
            "router_version": "routellm-bert-multithreshold-v1",
            "latency_ms": round((time.perf_counter() - t0) * 1000, 1)}
```

Run: `uvicorn routellm_sidecar:app --host 0.0.0.0 --port 8080 --workers 2`.

---

## 6. Evaluate

```bash
python -m routellm.evals.evaluate --routers random sw_ranking bert mf --benchmark gsm8k --config config.example.yaml
# benchmarks: mmlu, gsm8k, mt-bench ; results cached; plot written to cwd (override with --output)
```

Benchmarks use the GPT-4/Mixtral pair by default (`--strong-model`, `--weak-model` to change, but you'd need to precompute results for your pair — see the benchmark directories). For your chatbot, prefer the evaluation playbook on your own labeled data.

---

## 7. Retrain on your data

- Add a router: implement the abstract `Router` class in `routers.py` with one method, `calculate_strong_win_rate(prompt)`, and register it in `ROUTER_CLS`.
- Train a causal-LLM router: Anyscale's notebook https://github.com/anyscale/llm-router (fine-tune a classifier on your (prompt, label) data; their write-up reports up to 70% cost reduction on MT-Bench at baseline quality 📊).
- Your labels: pairwise "did strong beat weak?" from an LLM judge on your traffic (see playbook 01).

---

## 8. Deploy

- Containerize the server or sidecar (Python 3.10/3.11 base, `torch` CPU or CUDA wheels). BERT router runs on CPU acceptably for moderate traffic; GPU for high QPS.
- Preload checkpoints into the image (no Hugging Face download at startup); pin revisions.
- ≥ 2 replicas; readiness = model loaded; p95 latency SLO.

---

## 9. Gotchas

- Strictly **one prompt** — no conversation context (handle in your wrapper as above).
- Two models per decision; multi-tier needs your own bucketing.
- `mf` / `sw_ranking` need OpenAI embeddings (privacy implication).
- Thresholds are router-specific and traffic-specific — always recalibrate.

---

## 10. Official guides & links

- Repo & README: https://github.com/lm-sys/RouteLLM
- Paper: https://arxiv.org/abs/2406.18665
- LMSYS blog: https://lmsys.org/blog/2024-07-01-routellm/
- Routing to local models (Ollama): https://github.com/lm-sys/RouteLLM/blob/main/examples/routing_to_local_models.md
- Hugging Face artifacts: https://huggingface.co/routellm
- Arena preference dataset: https://huggingface.co/datasets/lmsys/lmsys-arena-human-preference-55k
- Anyscale "Building an LLM Router" tutorial/notebook: https://github.com/anyscale/llm-router
