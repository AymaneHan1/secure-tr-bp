# Guide 06 — LLMRouter (UIUC): Train and Compare Multi-Model Routers

## At a glance

| | |
|---|---|
| **What** | A unified open-source library of **16+ routing algorithms** with a data-generation pipeline, `train / infer / chat / serve` CLI, plugin system, OpenAI-compatible server, and the xRouteBench benchmark |
| **License** | MIT ✅ |
| **Repo / docs / paper** | https://github.com/ulab-uiuc/LLMRouter · https://ulab-uiuc.github.io/LLMRouter/ · https://arxiv.org/abs/2608.06867 |
| **Package** | `pip install llmrouter-lib` (v0.3.x) |
| **Status** | Active research library (paper Aug 2026, ~3k stars) |
| **Integration patterns** | A (route-only), B/C (OpenClaw-style server), D (Python) |
| **Best for** | Phase 2: training the best multi-model router on **your** labeled traffic and comparing algorithms fairly |

The paper reports learned routers outperform the strongest single fixed model by **14.6% (relative)**, and that lightweight and user-conditioned routers do especially well under tight cost budgets 📊.

---

## 1. Algorithms available ✅

| Category | Routers | Notes |
|---|---|---|
| Single-round | `knnrouter`, `svmrouter`, `mlprouter`, `racerrouter`, `mfrouter`, `elorouter`, `routerdc`, `automix`, `hybrid_llm`, `graphrouter`, `causallm_router`, baselines `smallest_llm`, `largest_llm` | kNN/SVM/MLP route **among many models** (not just two) |
| Multi-round | `router_r1` | Pre-trained Router-R1 (RL) for multi-turn routing/aggregation; GPU, pinned vLLM 0.6.3 / torch 2.4.0 |
| Multimodal | `tsrouter` | time-series modality–model routing |
| Personalized | `gmtrouter`, `personalizedrouter` | GNN-based user-preference routing |
| Agentic | `knnmultiroundrouter`, `llmmultiroundrouter` | LLM-based one needs no training — uses model descriptions from config |
| Custom | your `MetaRouter` subclass | plugin discovery from `./custom_routers/`, `~/.llmrouter/plugins/`, `$LLMROUTER_PLUGINS` |

**Which to start with:** `knnrouter` (strong, interpretable baseline) and `mlprouter` (fast, usually better with enough data). Try `graphrouter` and `routerdc` once you have ≥ 10k labeled examples. Use `smallest_llm`/`largest_llm` as reference points.

---

## 2. Install

```bash
# PyPI
pip install llmrouter-lib

# or source (recommended while learning — configs and examples live in the repo)
git clone https://github.com/ulab-uiuc/LLMRouter.git && cd LLMRouter
conda create -n llmrouter python=3.10 && conda activate llmrouter
pip install -e .
# optional extras
pip install -e ".[router-r1]"   # GPU, pins vllm==0.6.3 / torch==2.4.0
pip install -e ".[all]"
```

---

## 3. Point LLMRouter at your inference API

**API keys** — service-specific dict format (keys match the `service` field of each candidate):

```bash
export API_KEYS='{"Internal": "'"$INFERENCE_API_KEY"'"}'
```

**Candidate LLMs** — `data/my_llm_candidates.json` (fields per the README: `service`, `model`, `api_endpoint`, plus metadata such as `size`, `feature`, `input_price`, `output_price` used by some routers and the cost objective):

```json
{
  "fast-mini": {
    "service": "Internal", "model": "fast-mini",
    "api_endpoint": "https://inference.internal.example.com/v1",
    "size": "8B", "feature": "fast, cheap; greetings, short factual answers, rewrites",
    "input_price": 0.15, "output_price": 0.60
  },
  "general-small": {
    "service": "Internal", "model": "general-small",
    "api_endpoint": "https://inference.internal.example.com/v1",
    "size": "30B", "feature": "balanced; everyday questions, summaries, emails",
    "input_price": 0.50, "output_price": 1.50
  },
  "general-large": {
    "service": "Internal", "model": "general-large",
    "api_endpoint": "https://inference.internal.example.com/v1",
    "size": "large", "feature": "analysis, long documents, nuanced writing",
    "input_price": 3.0, "output_price": 15.0
  },
  "code-specialist": {
    "service": "Internal", "model": "code-specialist",
    "api_endpoint": "https://inference.internal.example.com/v1",
    "size": "large", "feature": "code generation, debugging, SQL, infrastructure config",
    "input_price": 2.5, "output_price": 10.0
  },
  "reasoning-frontier": {
    "service": "Internal", "model": "reasoning-frontier",
    "api_endpoint": "https://inference.internal.example.com/v1",
    "size": "frontier", "feature": "hard multi-step reasoning, math, planning",
    "input_price": 15.0, "output_price": 60.0
  }
}
```

(Prices here are illustrative, per million tokens. Use the units your router config expects — ⚠️ check `llmrouter/data/README.md` for the exact candidate schema.)

Endpoint resolution: per-model `api_endpoint` wins; otherwise the router YAML `api_endpoint`; otherwise a descriptive error ✅.

---

## 4. Build training data from YOUR traffic

LLMRouter's pipeline (3 steps) is built around 11 public benchmarks; for a company chatbot you want your own prompts. The target format is the **routing data JSONL** — one row per (query, model):

```json
{"task_name": "chatbot", "query": "Summarize this policy for a new hire …", "ground_truth": "",
 "metric": "llm_judge", "model_name": "general-small", "response": "…", "performance": 0.8,
 "embedding_id": 42, "token_num": 453}
```

Plus query embeddings (`.pt`) and LLM embeddings (`default_llm_embeddings.json`) produced by the pipeline's steps 2–3.

**Recommended approach:**

1. Use [playbook 01](../03-playbooks/01-build-your-own-router.md) to sample prompts, run all 5 models through your API, and score with an LLM judge → `performance` in [0, 1].
2. Write those rows in the routing-data format above.
3. Run the pipeline's embedding steps (or register a **custom task** with `@register_prompt` and a custom metric with `@evaluation_metric` — see `custom_tasks/README.md`).

Pipeline commands (for reference/benchmarks):

```bash
python llmrouter/data/data_generation.py        --config llmrouter/data/sample_config.yaml   # queries + split
python llmrouter/data/generate_llm_embeddings.py --config llmrouter/data/sample_config.yaml   # LLM metadata embeddings
python llmrouter/data/api_calling_evaluation.py  --config llmrouter/data/sample_config.yaml --workers 100  # call models, score
```

Full format docs: `llmrouter/data/README.md`.

---

## 5. Train

```bash
llmrouter train --router knnrouter --config configs/model_config_train/knnrouter.yaml
CUDA_VISIBLE_DEVICES=0 llmrouter train --router mlprouter --config configs/model_config_train/mlprouter.yaml --device cuda
llmrouter train --router mfrouter  --config configs/model_config_train/mfrouter.yaml --device cuda --quiet
```

Copy the provided training configs and change `data_path` entries (`llm_data` → your candidates JSON, routing data/embeddings → your files). Keep a held-out test split of *your* traffic.

---

## 6. Use

```bash
# Route only — returns the chosen model, no LLM call, no API key needed
llmrouter infer --router knnrouter --config my_knn.yaml --query "Fix this SQL: SELECT …" --route-only

# Route + call the chosen model through your API
llmrouter infer --router knnrouter --config my_knn.yaml --query "Explain our expense policy"

# Batch (txt / json / jsonl)
llmrouter infer --router mlprouter --config my_mlp.yaml --input queries.jsonl --output results.json

# Interactive Gradio chat to eyeball decisions
llmrouter chat --router knnrouter --config my_knn.yaml --mode full_context --top_k 5
#   modes: current_only (default) | full_context (all history) | retrieval (top-k similar past queries)

llmrouter list-routers
```

**Decision-only sidecar (Pattern A):** load the trained router in a FastAPI process and call its routing method per request. Custom routers expose `route_single(query_input) -> {"model_name": ...}` (from the `MetaRouter` interface); built-in routers follow the same interface ⚠️ check the router's README for constructor/loading details:

```python
# llmrouter_sidecar.py (sketch)
from fastapi import FastAPI
from llmrouter.models.knnrouter import KNNRouter      # ⚠️ verify import path/class name per router README
router = KNNRouter(yaml_path="my_knn.yaml")           # loads trained artifacts per config
app = FastAPI()

@app.post("/route")
def route(req: dict):
    users = [m["content"] for m in req["messages"] if m["role"] == "user"]
    out = router.route_single({"query": users[-1]})
    return {"model": out["model_name"], "router_version": "llmrouter-knn-v1"}
```

**Server (Patterns B/C):** the OpenClaw Router is an OpenAI-compatible server that can run any LLMRouter strategy:

```yaml
# openclaw_router/config.yaml (adapted)
serve: {host: "0.0.0.0", port: 8000, show_model_prefix: false}
router:
  strategy: llmrouter                 # or: llm, random, round_robin, rules
api_keys:
  internal: ${INFERENCE_API_KEY}
llms:
  fast-mini:          {provider: internal, model: fast-mini,          base_url: https://inference.internal.example.com/v1, description: "Fast responses"}
  general-small:      {provider: internal, model: general-small,      base_url: https://inference.internal.example.com/v1, description: "Everyday tasks"}
  general-large:      {provider: internal, model: general-large,      base_url: https://inference.internal.example.com/v1, description: "Analysis, long docs"}
  code-specialist:    {provider: internal, model: code-specialist,    base_url: https://inference.internal.example.com/v1, description: "Code and SQL"}
  reasoning-frontier: {provider: internal, model: reasoning-frontier, base_url: https://inference.internal.example.com/v1, description: "Complex reasoning"}
```

```bash
llmrouter serve --config openclaw_router/config.yaml --router knnrouter
curl http://localhost:8000/v1/chat/completions -H "Content-Type: application/json" \
  -d '{"model":"auto","messages":[{"role":"user","content":"Explain quantum computing"}]}'
```

Optional server features: routing **memory** (retrieval of similar past routes), **media understanding** (convert images/audio/video to text for routing), streaming. ⚠️ The OpenClaw integration targets messaging platforms; for production chatbots, wrap the router in your own hardened service.

---

## 7. Write your own router (plugin)

```python
# custom_routers/policy_router/router.py
from llmrouter.models.meta_router import MetaRouter
import torch.nn as nn

class PolicyRouter(MetaRouter):
    def __init__(self, yaml_path: str):
        super().__init__(model=nn.Identity(), yaml_path=yaml_path)
        self.by_price = sorted(self.llm_data, key=lambda m: self.llm_data[m]["input_price"])

    def route_single(self, query_input: dict) -> dict:
        q = query_input["query"]
        if any(k in q.lower() for k in ("sql", "python", "stack trace", "```")):
            choice = "code-specialist"
        elif len(q) < 60:
            choice = self.by_price[0]
        else:
            choice = "general-small"
        return {"query": q, "model_name": choice, "predicted_llm": choice}

    def route_batch(self, batch: list) -> list:
        return [self.route_single(x) for x in batch]
```

```bash
llmrouter infer --router policy_router --config custom_routers/policy_router/config.yaml --query "hi"
```

Docs: `custom_routers/README.md`, `CUSTOM_ROUTER_SUMMARY.md`.

---

## 8. Benchmark (xRouteBench)

```bash
cd benchmark_pipeline
python download_data.py            # HF: ulab-ai/xRouteBench
python generate_embeddings.py      # Qwen3-Embedding-0.6B query embeddings
python run_pipeline.py --datasets all --routers local   # 13 local routers, zero API cost (replays pre-recorded executions)
python aggregate_results.py --csv
```

Use this to learn how algorithms compare before spending on your own labels.

---

## 9. Visual workflow (ComfyUI)

Symlink `LLMRouter/ComfyUI` into `ComfyUI/custom_nodes/LLMRouter`, load `llm_router_example.json`, and build Data Generation → Training → Evaluation by drag-and-drop. Useful for teaching the team.

---

## 10. Deploy

- Training: a GPU box (or CPU for kNN/SVM). Version the dataset, config, and artifacts together (e.g., DVC or MLflow).
- Serving: your own FastAPI sidecar container with the trained artifact baked in; CPU is enough for kNN/MLP on precomputed-dimension embeddings (embedding model may want a small GPU at high QPS).
- Retrain cadence: monthly, or whenever you change one of your 5 models.

---

## 11. Gotchas

- Research code: pin commit SHAs; expect API changes between releases.
- Default data pipeline uses public benchmarks — **your traffic differs**; build your own labels.
- Some routers need heavy pinned deps (Router-R1).
- The library's embedding defaults (e.g., Longformer in the default pipeline; Qwen3-Embedding-0.6B in the benchmark) determine the feature space — keep training and serving embeddings identical.

---

## 12. Official guides & links

- Repo / README: https://github.com/ulab-uiuc/LLMRouter
- Docs site: https://ulab-uiuc.github.io/LLMRouter/
- Paper (Aug 2026): https://arxiv.org/abs/2608.06867 · HF Daily Papers: https://huggingface.co/papers/2608.06867
- xRouteBench dataset: https://huggingface.co/datasets/ulab-ai/xRouteBench
- Data pipeline docs: `llmrouter/data/README.md` · Custom routers: `custom_routers/README.md` · Custom tasks: `custom_tasks/README.md` · OpenClaw server: `openclaw_router/README.md`
- PyPI: https://pypi.org/project/llmrouter-lib/
- Related: RouteProfile https://github.com/ulab-uiuc/RouteProfile · Router-R1 https://github.com/ulab-uiuc/Router-R1 · GraphRouter paper https://arxiv.org/abs/2410.03834 · RouterDC https://arxiv.org/abs/2409.19886 · AutoMix https://arxiv.org/abs/2310.12963 · Hybrid LLM https://arxiv.org/abs/2404.14618
