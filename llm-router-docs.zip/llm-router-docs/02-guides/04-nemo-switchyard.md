# Guide 04 — NVIDIA NeMo Switchyard

## At a glance

| | |
|---|---|
| **What** | A Rust proxy **and** library for LLM traffic: routes requests between model tiers, translates between OpenAI Chat / Anthropic Messages / OpenAI Responses, exposes Prometheus metrics |
| **License** | Open source (confirm the LICENSE file in the repo) |
| **Repo** | https://github.com/NVIDIA-NeMo/Switchyard (open-sourced May 2026) |
| **Status** | **Pre-alpha** — APIs expected to change before v1.0 ✅. CLI `nemo-switchyard` v0.2.0 in the Sept 2026 KDnuggets tutorial |
| **Predecessor** | Replaces NVIDIA's deprecated *AI Blueprint: LLM Router* (v1 Rust+Triton, v2 NeMo Agent Toolkit) |
| **Routing families** | Random/weighted A/B, LLM-as-classifier (`p_solve`), stage routing from conversation signals, escalation with a judge, custom algorithms |
| **Integration patterns** | B, C (server); A and D via `switchyard-libsy` (Rust; decision-only by design) |
| **Best for** | Agentic, multi-turn, tool-using workflows; escalation-style routing |

---

## 1. How it works

Each **route** (a model ID clients call) has a **type** and tier targets — typically `strong` and `weak`:

| Strategy | Idea | When to use |
|---|---|---|
| **Random** | Fixed split (e.g., 30% strong) | A/B tests, baselines, validating the proxy |
| **LLM classifier** | A judge model estimates if the weak tier can solve the turn (`p_solve`) and applies a threshold | Content should decide weak vs. strong |
| **Stage router** | Uses signals already in the conversation (tool errors, repeated unproductive steps, exploration vs. execution) to route most turns **without an extra model call**; optional judge fallback | Long coding/agent sessions |
| **Escalation** | Every turn goes to the weak tier first; a judge reads the result and escalates the **same request** to strong on sustained trouble | When you'd rather observe failure than predict difficulty |
| **Passthrough** | One target, no decision | Registering plain models |

> ⚠️ **Naming changed across versions.** The Sept 2026 tutorial uses `type: random_routing`, `type: deterministic` (classifier), `type: stage_router`, `type: escalation_router`. The repo docs (Aug 2026) list route types `llm_classifier`, `stage_router`, `random`, `passthrough`, with escalation as `llm_classifier` + `mode = "escalation"`. **Check `docs/routing_algorithms/` for your installed version.**

NVIDIA-reported results 📊: Boomi reached 100% domain-routing accuracy across five routing functions and sent 59% of traffic to a 5× faster fine-tuned model; LangChain reported 74% lower cost on 145 multi-turn tasks by sending 7% of calls to a frontier model, with a 6% accuracy trade-off. Kong AI Gateway is delivering Switchyard routing and LiteLLM is adding it as a plugin.

---

## 2. Install

```bash
# CLI + server via uv (Python-distributed launcher around the Rust server)
uv tool install "nemo-switchyard[cli,server]"
switchyard --version

# or the native Rust server
cargo install --locked switchyard-server

# Opt out of telemetry for company traffic
export SWITCHYARD_TELEMETRY_OPT_OUT=1
```

Three execution paths ✅:

- **Launcher path:** wraps Claude Code / Codex CLI / OpenClaw (developer tooling).
- **Server path:** standalone proxy — what you want for the chatbot.
- **Library path:** `switchyard-libsy` embedded in your Rust app; it **never calls a model itself**, it yields `Step::CallLlm` steps that your host executes and ends with `Step::ReturnToAgent`.

---

## 3. Configure — mapping five models onto strong/weak routes

Switchyard routes are two-tier. With five models, compose several routes and pick the route upstream (cheap rules in your API), or nest decisions:

| Route ID (what your API calls) | weak | strong | Strategy |
|---|---|---|---|
| `chat-general` | `fast-mini` | `general-large` | classifier |
| `chat-code` | `general-small` | `code-specialist` | classifier |
| `chat-hard` | `general-large` | `reasoning-frontier` | escalation |
| `ab-baseline` | `general-small` | `general-large` | random 30% strong |

`routes.yaml` (⚠️ shape follows the Sept 2026 tutorial; adjust `type` names to your version):

```yaml
defaults:
  base_url: ${INFERENCE_API_BASE}          # your inference API (OpenAI-compatible)
  api_key: ${INFERENCE_API_KEY}            # never inline secrets

routes:
  chat-general:
    type: deterministic                    # ⚠️ newer docs: llm_classifier
    classifier:
      model: fast-mini                     # cheap judge from YOUR API
    weak:
      model: fast-mini
    strong:
      model: general-large
    profile: general
    session_affinity: true
    fallback_target_on_evict: weak

  chat-code:
    type: deterministic
    classifier:
      model: fast-mini
    weak:
      model: general-small
    strong:
      model: code-specialist
    profile: general
    session_affinity: true
    fallback_target_on_evict: weak

  chat-hard:
    type: escalation_router                # ⚠️ newer docs: llm_classifier with mode = "escalation"
    weak:
      model: general-large
    strong:
      model: reasoning-frontier
    judge:
      model: general-small
      confirmations: 2                     # sustained trouble before escalating
      recent_turn_window: 28
      window_message_chars: 500
    fallback_target_on_evict: weak

  ab-baseline:
    type: random_routing                   # ⚠️ newer docs: random
    weak:
      model: general-small
    strong:
      model: general-large
    strong_probability: 0.3
    rng_seed: 42
    fallback_target_on_evict: weak
```

`fallback_target_on_evict` (a tier ID) is required for these route types in the tutorial version.

---

## 4. Run and test

```bash
switchyard serve -c routes.yaml --host 0.0.0.0 --port 4000
curl -s http://127.0.0.1:4000/health                 # {"status":"ok"}

curl http://localhost:4000/v1/chat/completions -H "Content-Type: application/json" \
  -d '{"model":"chat-general","messages":[{"role":"user","content":"What is 15% of 200?"}]}'
# → served by weak tier (fast-mini)

curl -s http://localhost:4000/metrics | head          # Prometheus
curl -s http://localhost:4000/v1/stats | jq .         # aggregate JSON statistics
```

There's no dry-run flag in the tested CLI — startup *is* validation (invalid bundles fail at start).

---

## 5. Use from your ecosystem

- **Pattern C (recommended):** your API keeps its contract; when `model="auto"`, it applies cheap rules to choose `chat-code` vs. `chat-general` vs. `chat-hard`, then calls Switchyard with that route ID. Switchyard calls your API's per-model endpoints back (ensure that internal path doesn't re-enter `auto`).
- **Pattern B:** clients call Switchyard directly with a route ID.
- **Pattern A/D (Rust shops):** embed `switchyard-libsy`:

```toml
[dependencies]
async-trait = "0.1"
futures = "0.3"
switchyard-libsy = { git = "https://github.com/NVIDIA-NeMo/Switchyard.git" }
switchyard-protocol = { git = "https://github.com/NVIDIA-NeMo/Switchyard.git" }
tokio = { version = "1", features = ["macros", "rt"] }
```

Algorithms in the library: `LlmTaskClassifier` (with optional escalation mode), `StageRouter`, `Random` (any number of targets, weighted). Your host performs each `Step::CallLlm` over its own transport — retries, credentials, and logging stay in your API. Pair with `switchyard-llm-client` if you want Switchyard to make calls.

---

## 6. Deploy

- Single static binary or container; stateless except for in-memory session affinity → use sticky sessions at the load balancer, or keep affinity in your API.
- Run ≥ 2 replicas behind a Service; scrape `/metrics`; alert on error rate and strong-tier share.
- Pin the version (pre-alpha); keep a contract test suite that hits each route with known prompts.

---

## 7. Measuring value (adapted from the KDnuggets tutorial)

Always compare three configurations on the same task set:

| Run | Purpose |
|---|---|
| Always strong | Quality ceiling, cost baseline |
| Always weak | Cheap baseline |
| Switchyard route | Does it keep most of strong's quality at much lower cost? |

Report "% of strong quality preserved" and "% cost/latency reduced", not router accuracy alone.

---

## 8. Gotchas

- Pre-alpha: breaking changes in route type names and fields have already happened.
- Two tiers per route — five-model setups need composition.
- Escalation adds latency for escalated turns (weak answer + judge + strong answer) — better for agents than for live streaming chat, unless the judge runs before streaming to the user.
- Telemetry: set `SWITCHYARD_TELEMETRY_OPT_OUT=1`.

---

## 9. Official guides & links

- Repo: https://github.com/NVIDIA-NeMo/Switchyard
- Getting started: `docs/getting_started.md` in the repo; routing algorithms: `docs/routing_algorithms/` (overview, llm_classifier, stage_router, escalation_router, random)
- NVIDIA technical blog on Switchyard routing: https://developer.nvidia.com/blog?p=120999
- KDnuggets hands-on tutorial (Sept 2026): https://www.kdnuggets.com/switchyard-nvidias-open-source-routing-library
- Launch coverage (Nemotron 3.5 Lightning + Switchyard): https://itbrief.com.au/story/nvidia-launches-nemotron-3-5-lightning-switchyard
- Deprecated predecessor (for history/ideas): https://github.com/NVIDIA-AI-Blueprints/llm-router · https://build.nvidia.com/nvidia/llm-router
