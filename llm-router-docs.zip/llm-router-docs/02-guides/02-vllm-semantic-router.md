# Guide 02 — vLLM Semantic Router (vLLM-SR)

## At a glance

| | |
|---|---|
| **What** | An open, programmable **decision layer** for Mixture-of-Models: extracts signals from each request, applies prioritized decisions, runs plugins (cache, PII, jailbreak, hallucination detection), selects or combines models |
| **License** | Apache-2.0 ✅ |
| **Repo / docs** | https://github.com/vllm-project/semantic-router · https://vllm-sr.ai |
| **Status** | Stable **v0.4.0 "Hermes"** (PyPI, Sep 2026); 0.5 dev builds in progress. Milestones: v0.1 Iris (Jan 2026), v0.2 Athena (Mar 2026), v0.3 Themis (Jun 2026) ✅ |
| **Runtime** | Router + Envoy (ext_proc) + Dashboard + Prometheus + Jaeger (containers); Helm for Kubernetes |
| **Integration patterns** | B (in front), C (behind); A only for preview/evaluation |
| **Best for** | Platform teams wanting routing + guardrails + semantic caching + observability in one Kubernetes-native layer |

---

## 1. How it works

```
client ─▶ Envoy listener (:8899, OpenAI-compatible, model "vllm-sr/auto")
            │  ext_proc
            ▼
        Router
          ├─ Signals   → what is this request? (domain/intent, keywords, embeddings, complexity, context, user prefs…)
          ├─ Decisions → ordered rules: if signals match → which model(s) + algorithm
          ├─ Algorithms→ static pick, or model-selection algorithms (ML-based selection, fusion of several models)
          └─ Plugins   → semantic cache, PII, jailbreak guard, hallucination detection, tool filtering…
            ▼
        backend model endpoints (your inference API)
```

Key ideas:

- **Signal-Decision architecture** (introduced in v0.1): instead of a fixed 14-category classifier, you compose many signals into unlimited decisions.
- **Decisions** live in `routing.decisions[]`, each with `name`, `description`, `priority`, `rules` (boolean `operator` + `conditions`), `modelRefs`, and an `algorithm`.
- **Model cards** (`routing.modelCards`) describe models; **providers** (`providers.models`) say how to reach them.
- **Stateful routing** (v0.3): conversation-aware decisions for production chat/agents.
- **Fusion** (2026): combine multiple models' outputs in one call (Mixture-of-Models).
- **Recipes**: maintained starter configs; the Dashboard lets you connect models and assign them to a recipe's decisions.
- **Own model families** on Hugging Face: MoM classifiers (domain, PII, jailbreak, factuality…), Vela routing foundation models, Decision models.

---

## 2. Prerequisites

- Linux, macOS, or WSL2 with **Docker or Podman** (local `serve` runs containers; native Windows can only run config commands).
- Python ≥ 3.10 for the CLI.
- GPU optional but recommended for classifier signals at scale (`--platform nvidia` / `--platform amd` shortcuts locally).
- Your inference API reachable from the router containers.
- **Note:** `vllm-sr serve` starts the routing stack only — it does **not** start model backends. Your API must already be running.

**Install**

```bash
# Official installer (stable channel)
curl -fsSL https://vllm-sr.ai/install.sh | bash -s -- --channel stable

# or via pip
pip install vllm-sr
vllm-sr --version
```

---

## 3. Configure — five models via your inference API

The CLI reads canonical YAML with top-level keys **`version / listeners / providers / routing / global`**. The schema evolves quickly, so the authoritative field reference is generated in the configuration guide and examples live in `config/fragments/` in the repo.

**Recommended approach:**

1. `vllm-sr serve` (no config) → open the Dashboard at http://localhost:8700.
2. Connect your 5 models as provider Models (base URL = your API, model alias per entry).
3. Choose a built-in **Recipe** (or custom) and assign your models to its decisions.
4. Export the resulting YAML into Git; from then on, `vllm-sr config validate` + `vllm-sr serve --config my-models.yaml`.

**Illustrative skeleton** (⚠️ shape only — validate against the current reference; only the `routing.decisions` block below is copied from documented examples):

```yaml
version: v0.3                      # ⚠️ use the version your CLI expects

listeners:
  - address: 0.0.0.0              # 127.0.0.1 for host-only access
    port: 8899                     # routed OpenAI-compatible listener

providers:
  models:                          # ⚠️ field names per configuration guide
    - name: fast-mini
      # endpoint: ${INFERENCE_API_BASE}, model id: fast-mini, credential via env reference
    - name: general-small
    - name: general-large
    - name: code-specialist
    - name: reasoning-frontier

routing:
  modelCards:                      # ⚠️ describe each model (capabilities, cost hints)
    - name: fast-mini
    - name: general-small
    - name: general-large
    - name: code-specialist
    - name: reasoning-frontier

  decisions:
    # Highest priority first. Conditions reference signals you define (⚠️ see fragments).
    - name: code-tasks
      description: Programming, debugging, SQL, infrastructure-as-code
      priority: 300
      rules:
        operator: OR
        conditions: []             # e.g. domain signal == computer_science, keyword signal == code
      modelRefs:
        - model: code-specialist
      algorithm:
        type: static

    - name: hard-reasoning
      description: Multi-step reasoning, math, planning
      priority: 200
      rules:
        operator: OR
        conditions: []             # e.g. complexity/reasoning signal high
      modelRefs:
        - model: reasoning-frontier
      algorithm:
        type: static

    - name: everyday
      description: Common questions, summaries, emails
      priority: 100
      rules:
        operator: AND
        conditions: []
      modelRefs:
        - model: general-small
      algorithm:
        type: static

    # Documented final fallback pattern: empty conditions, priority 0
    - name: local-fallback
      description: Handle requests that did not match an earlier decision.
      priority: 0
      rules:
        operator: AND
        conditions: []
      modelRefs:
        - model: fast-mini
      algorithm:
        type: static

global: {}
```

**Credentials:** keep them out of YAML; reference environment variables. For recipe-specific variables, authorize explicitly:

```bash
export PROVIDER_API_KEY=$INFERENCE_API_KEY
vllm-sr serve --config my-models.yaml --recipe-env PROVIDER_API_KEY
```

**Migrating old configs:** `vllm-sr init` was removed in v0.3. Use `vllm-sr config migrate --config old-config.yaml` or `vllm-sr config import --from openclaw --source openclaw.json --target config.yaml`.

---

## 4. Run locally

```bash
vllm-sr serve --config my-models.yaml          # Router, Envoy, Dashboard, observability
vllm-sr serve --minimal --config my-models.yaml   # Router + Envoy only
vllm-sr status
vllm-sr dashboard                               # opens http://localhost:8700
vllm-sr logs router | vllm-sr logs envoy | vllm-sr logs dashboard
vllm-sr stop
```

Default local ports ✅:

| Service | Port |
|---|---|
| Dashboard | 8700 |
| Routed inference listener (OpenAI-compatible) | 8899 |
| Router management API (eval, config, replay, vector stores) | 8080 |
| Router metrics (Prometheus) | 9190 |
| Jaeger UI | 16686 |
| Prometheus | 9090 |

First startup can take a while (model downloads); `--startup-timeout 7200` extends the default 1,800 s wait.

---

## 5. Use and test

**Preview a decision without calling a backend** (management API):

```bash
vllm-sr route preview --prompt "Explain inflation in plain English."
vllm-sr route preview --prompt "Fix this SQL: SELECT * FROM t WHERE ..." --json
vllm-sr route preview --messages '[{"role":"user","content":"Explain inflation."}]' --endpoint http://localhost:8080
```

It reports which **signals, decision, algorithm, and plugins** matched — perfect for building a regression test suite of prompts → expected decision.

**Send a real request through the router:**

```bash
vllm-sr request chat "Hello"                       # uses model vllm-sr/auto
vllm-sr request chat --model my-virtual-model --json "Hello"

curl http://localhost:8899/v1/chat/completions -H "Content-Type: application/json" \
  -d '{"model":"vllm-sr/auto","messages":[{"role":"user","content":"Write a Python function to dedupe a list"}]}'
```

From your ecosystem: clients (Pattern B) or your API (Pattern C) call `http://<router>:8899/v1` with `model: "vllm-sr/auto"` (or a virtual model you publish; published names appear in `/v1/models`).

**Regression tests in CI:**

```bash
vllm-sr config validate --config my-models.yaml
# then run a script that calls `vllm-sr route preview --json` for 100+ labeled prompts
# and fails the build if accuracy vs expected decisions drops
```

---

## 6. Deploy to Kubernetes

The CLI can install/upgrade the Helm release for you:

```bash
vllm-sr serve --target k8s --profile dev --namespace semantic-router --config my-models.yaml
vllm-sr status --target k8s --namespace semantic-router
vllm-sr logs router --target k8s --namespace semantic-router -f
vllm-sr stop --target k8s --namespace semantic-router
```

Or Helm directly (as documented at v0.1): `helm install semantic-router oci://ghcr.io/vllm-project/charts/semantic-router`.

Production notes ✅:

- Kubernetes requires a **complete, non-empty config** (no local defaults are merged).
- Credential references go into a release-scoped Secret; **literal credentials or credential-bearing URLs are rejected**.
- GPU images/resources/device plugins are selected through Helm values, profiles, or the operator.
- See the Kubernetes installation guide for gateway integration and production profiles: https://vllm-sr.ai/docs/installation/k8s/
- Fits with the **vLLM Production Stack** if you also self-host models.

Operational practices:

- Run ≥ 2 router replicas; Envoy scales horizontally.
- Scrape `:9190` metrics; ship traces to your Jaeger/Tempo.
- Use the **Evaluation Plane** to compare a baseline and a candidate deployment from one Dashboard (`EVALUATION_DEPLOYMENTS_DIR`).
- For multiple local stacks: `VLLM_SR_STACK_NAME` + `VLLM_SR_PORT_OFFSET`.

---

## 7. Tuning

- Start from a Recipe close to your use case; replace models with your 5 aliases.
- Write **decision descriptions** clearly and keep decisions mutually exclusive where possible; use priority for overlaps.
- Build a labeled prompt set (200–500) and track decision accuracy with `route preview`.
- Enable plugins gradually: semantic cache first (big cost win for repetitive enterprise questions), then PII/jailbreak in log-only mode before enforcing.
- Explore model-selection algorithms (the project lists kNN, k-means, MLP, SVM, matrix factorization, Elo, RouterDC, AutoMix, hybrids as research directions) once static decisions are stable.

---

## 8. Gotchas

- **Fast-moving schema:** pin the CLI version; read release notes (v0.3 removed `init`, changed canonical YAML).
- Healthy Router/Envoy ≠ healthy backend: use Dashboard **Verify** or `request chat` to test the path to your API.
- `route preview` uses the management API (8080); `request chat` uses the routed listener (8899) — don't mix them up.
- Resource footprint is larger than a single-container gateway; budget CPU/GPU for classifier signals.

---

## 9. Official guides & links

- Repo: https://github.com/vllm-project/semantic-router
- Docs home: https://vllm-sr.ai · Installation: https://vllm-sr.ai/docs/installation/
- Configuration reference: https://vllm-sr.ai/docs/installation/configuration/
- Kubernetes: https://vllm-sr.ai/docs/installation/k8s/
- Connect an agent harness: https://vllm-sr.ai/docs/installation/agent-harness/
- Online playground: https://app.vllm-sr.ai/playground
- PyPI CLI: https://pypi.org/project/vllm-sr/
- Hugging Face org: https://huggingface.co/vllm-sr (older classifier models also under https://huggingface.co/llm-semantic-router)
- Releases/blogs: v0.1 Iris https://blog.vllm.ai/2026/01/05/vllm-sr-iris.html · v0.2 Athena https://vllm.ai/blog/v0.2-vllm-sr-athena-release · v0.3 Themis https://vllm-sr.ai/blog/v0.3-vllm-sr-themis-release/ · v0.4 Hermes https://vllm-sr.ai/blog/v0.4-vllm-sr-hermes-release/
- Architecture deep dives: Signal-Decision https://blog.vllm.ai/2025/11/19/signal-decision.html · Fusion https://vllm-sr.ai/blog/vllm-sr-fusion-api/ · Mixture-of-Models https://vllm-sr.ai/blog/vllm-sr-new-chapter-mom/
- Papers: "When to Reason: Semantic Router for vLLM" https://arxiv.org/abs/2510.08731 · Category-Aware Semantic Caching https://arxiv.org/abs/2510.26835 · Vision paper https://vllm-sr.ai/vision-paper · White paper https://vllm-sr.ai/white-paper/
- Community: `#semantic-router` in vLLM Slack; DeepWiki: https://deepwiki.com/vllm-project/semantic-router
