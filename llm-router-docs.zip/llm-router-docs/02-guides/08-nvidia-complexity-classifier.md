# Guide 08 — NVIDIA Prompt Task & Complexity Classifier

## At a glance

| | |
|---|---|
| **What** | A multi-headed DeBERTa-v3-base model that classifies a prompt's **task type** (11 classes) and scores **six complexity dimensions**, plus an overall complexity score |
| **License** | NVIDIA Open Model License Agreement — marked ready for commercial use; not an OSI license ⚠️ (legal review) |
| **Model card** | https://huggingface.co/nvidia/prompt-task-and-complexity-classifier · NGC: https://catalog.ngc.nvidia.com/orgs/nvidia/teams/nemo/models/prompt-task-and-complexity-classifier |
| **Version** | v1.1 ✅ |
| **Training data** | 4,024 human-annotated English prompts ✅ |
| **Input** | English text, default max length 512 tokens ✅ |
| **Integration patterns** | A (sidecar), D (embedded, if your API has a GPU) |
| **Best for** | A ready-made difficulty + task sensor; features for your learned router |

History: this classifier powered the v1 **NVIDIA AI Blueprint: LLM Router** (task and complexity routing with Triton). That blueprint is now deprecated in favor of NeMo Switchyard (guide 04), but the classifier itself remains a useful component.

---

## 1. What it outputs ✅

**Task types (11):** Open QA, Closed QA, Summarization, Text Generation, Code Generation, Chatbot, Classification, Rewrite, Brainstorming, Extraction, Other. Returns top-2 tasks with probability.

**Complexity dimensions (0–1 unless noted):**

| Dimension | Meaning |
|---|---|
| Creativity | creativity required to answer |
| Reasoning | logical/cognitive effort required |
| Contextual knowledge | background info needed beyond the prompt |
| Domain knowledge | specialized expertise required |
| Constraints | number of conditions/constraints in the prompt |
| Number of few-shots | count of examples provided (0–n) |

**Overall score:** `0.35·Creativity + 0.25·Reasoning + 0.15·Constraints + 0.15·DomainKnowledge + 0.05·ContextualKnowledge + 0.05·FewShots`.

> **Design note:** creativity has the largest weight in the overall score. "Write a fun poem" scores high but rarely needs your most expensive model. For cost routing, build your own **need score** from the individual dimensions (reasoning and domain knowledge matter most).

Reported 10-fold top-1 accuracies 📊: task 0.981, creativity 0.996, reasoning 0.997, contextual 0.981, few-shots 0.979, domain 0.937, constraints 0.991 (on their annotated data — your traffic will differ).

---

## 2. Install & load

```bash
pip install torch transformers huggingface_hub fastapi uvicorn
```

The model uses a custom PyTorch class (`PyTorchModelHubMixin` + multiple heads on a DeBERTa backbone). **Copy the `MeanPooling`, `MulticlassHead`, and `CustomModel` classes verbatim from the "How to Use in Transformers" section of the model card** into `nvidia_ptc.py`, then:

```python
# load_ptc.py
import torch
from transformers import AutoConfig, AutoTokenizer
from nvidia_ptc import CustomModel        # classes copied from the model card

REPO = "nvidia/prompt-task-and-complexity-classifier"
config = AutoConfig.from_pretrained(REPO)
tokenizer = AutoTokenizer.from_pretrained(REPO)
model = CustomModel(
    target_sizes=config.target_sizes,
    task_type_map=config.task_type_map,
    weights_map=config.weights_map,
    divisor_map=config.divisor_map,
).from_pretrained(REPO)
model.eval()
device = "cuda" if torch.cuda.is_available() else "cpu"
model.to(device)

def classify(prompts: list[str]) -> dict:
    enc = tokenizer(prompts, return_tensors="pt", add_special_tokens=True,
                    max_length=512, padding="max_length", truncation=True).to(device)
    with torch.no_grad():
        return model(enc)
# Example result keys (per model card): task_type_1, task_type_2, task_type_prob,
# creativity_scope, reasoning, contextual_knowledge, number_of_few_shots,
# domain_knowledge, no_label_reason, constraint_ct, prompt_complexity_score
```

⚠️ The exact constructor/keys follow the model card's code; if they change, the card is the source of truth.

**Batch / offline analysis:** NeMo Curator ships `PromptTaskComplexityClassifier` for GPU batch labeling of large prompt logs — ideal to profile your historical traffic before choosing tier thresholds: https://github.com/NVIDIA-NeMo/Curator (tutorial notebook: `tutorials/text/distributed-data-classification/prompt-task-complexity-classification.ipynb`).

---

## 3. Map outputs to your five models

```python
# policy.py
def need_score(r: dict, i: int = 0) -> float:
    """Cost-relevant difficulty (not creativity-dominated). Tune weights on your labels."""
    return (0.45 * r["reasoning"][i] + 0.25 * r["domain_knowledge"][i]
            + 0.15 * r["constraint_ct"][i] + 0.15 * r["contextual_knowledge"][i])

CODE_TASKS = {"Code Generation"}
CHEAP_TASKS = {"Chatbot", "Rewrite", "Classification", "Extraction"}

def choose_model(r: dict, i: int = 0) -> tuple[str, str]:
    task = r["task_type_1"][i]
    s = need_score(r, i)
    if task in CODE_TASKS:
        return ("code-specialist", f"task=code s={s:.2f}") if s >= 0.25 else ("general-small", f"task=code-simple s={s:.2f}")
    if r["reasoning"][i] >= 0.65 or s >= 0.55:
        return "reasoning-frontier", f"reasoning={r['reasoning'][i]:.2f} s={s:.2f}"
    if s >= 0.35 or task == "Summarization" and r["contextual_knowledge"][i] >= 0.5:
        return "general-large", f"s={s:.2f}"
    if task in CHEAP_TASKS and s < 0.15:
        return "fast-mini", f"task={task} s={s:.2f}"
    return "general-small", f"default s={s:.2f}"
```

Thresholds above are starting points. Calibrate them by labeling 500–1,000 real prompts (playbook 01) and choosing cut-offs that maximize quality-at-budget.

---

## 4. Serve as a sidecar (Pattern A)

```python
# ptc_service.py
import time
from fastapi import FastAPI
from pydantic import BaseModel
from load_ptc import classify
from policy import choose_model

app = FastAPI()

class RouteReq(BaseModel):
    messages: list[dict]
    metadata: dict = {}

def build_text(messages: list[dict]) -> str:
    users = [m["content"] for m in messages if m.get("role") == "user" and isinstance(m.get("content"), str)]
    last = users[-1] if users else ""
    if len(last) < 40 and len(users) > 1:          # short follow-up → include previous asks
        last = "\n".join(users[-3:])
    return last[-4000:]                             # keep the ask; 512-token model window

@app.post("/route")
def route(req: RouteReq):
    t0 = time.perf_counter()
    r = classify([build_text(req.messages)])
    model, why = choose_model(r)
    return {"model": model, "reason": f"nvidia-ptc:{why}",
            "features": {k: (v[0] if isinstance(v, list) else v) for k, v in r.items()},
            "router_version": "ptc-v1.1-policy-v1",
            "latency_ms": round((time.perf_counter() - t0) * 1000, 1)}
```

```bash
uvicorn ptc_service:app --host 0.0.0.0 --port 8082 --workers 1   # one worker per GPU
```

Performance tips: use `padding="longest"` instead of `max_length` for lower latency on short prompts; enable fp16 autocast on GPU; micro-batch concurrent requests if QPS is high; export to ONNX/TensorRT for further speedups.

---

## 5. Deploy

- **Hardware:** the card lists NVIDIA GPUs Volta+ (CUDA 12+) and tested on A10G; CPU inference works for low QPS but expect tens to 100+ ms at 512 tokens.
- Bake weights into the image; pin the model revision; expose `/healthz` that runs a tiny inference.
- Return the raw **features** in the response and log them — they become strong inputs for the learned router in playbook 01.

---

## 6. Gotchas

- English-centric, small training set (4,024 prompts) → validate on your traffic; consider fine-tuning heads on your labels.
- 512-token window: classify the **ask**, not a pasted 30-page document (long-context needs are handled by a separate context-length rule).
- Overall score is creativity-heavy — don't route on it alone.
- License is not OSI; commercial use is permitted under NVIDIA's terms — confirm with legal.

---

## 7. Official guides & links

- Hugging Face model card: https://huggingface.co/nvidia/prompt-task-and-complexity-classifier
- NGC catalog: https://catalog.ngc.nvidia.com/orgs/nvidia/teams/nemo/models/prompt-task-and-complexity-classifier
- NeMo Curator API docs: https://docs.nvidia.com/nemo/curator/0.25.7/apidocs/classifiers/classifiers.prompt_task_complexity.html
- NVIDIA blog — deploying the (now-deprecated) LLM Router blueprint, with task and complexity routing examples: https://developer.nvidia.com/blog/deploying-the-nvidia-ai-blueprint-for-cost-efficient-llm-routing/
- License: https://developer.download.nvidia.com/licenses/nvidia-open-model-license-agreement-june-2024.pdf
