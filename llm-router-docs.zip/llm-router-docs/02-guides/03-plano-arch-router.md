# Guide 03 — Plano (ex-Arch Gateway) + Arch-Router / Plano-Orchestrator

## At a glance

| | |
|---|---|
| **What** | An Envoy-based, OpenAI-compatible AI proxy ("data plane for agents") with three routing modes: model-based, alias-based, and **preference-aligned** routing driven by a fine-tuned routing LLM |
| **License** | Proxy: open source (confirm the LICENSE file in the repo). **Arch-Router-1.5B model: custom "katanemo-research" license** — get legal review before production ⚠️ |
| **Repo / docs** | https://github.com/katanemo/plano · https://docs.planoai.dev (v0.4.x) |
| **Company** | Katanemo Labs, now a DigitalOcean company |
| **Routing families** | LLM-as-router (fine-tuned), aliases, cost/latency-aware candidate ordering |
| **Integration patterns** | B (in front), C (behind); A by calling the router model directly |
| **Best for** | Routing between **specialists** by task/domain, with policy written in plain English |

---

## 1. How it works

You describe **routes** in natural language and attach an ordered **model pool** to each:

```yaml
routing_preferences:
  - name: code generation
    description: generating new code snippets, functions, or boilerplate based on user prompts
    models: [code-specialist, general-large]     # first = primary, rest = fallbacks on 429/5xx
```

At request time a routing model (**Plano-Orchestrator**, or the smaller **Arch-Router-1.5B**) reads the **conversation** (not the system prompt), infers the **domain** (e.g., legal, programming) and **action** (e.g., summarize, generate code), and picks the best-matching route. Adding or swapping a model = editing YAML; **no retraining**.

Extras:

- `selection_policy.prefer: cheapest | fastest | none` reorders a route's candidates using a **cost** catalog or **latency** from Prometheus.
- **Model affinity:** send `X-Model-Affinity: <id>` → first request routes, later requests reuse that model (TTL configurable, Redis for multi-replica).
- `routing.route_on_user_only: true` → route only at the start of a new user turn; agent-loop calls stay pinned.
- Filter chains (guardrails, moderation, memory hooks), tracing/metrics, `planoai obs` console with per-request USD cost.

**Difficulty vs. task:** Plano routes by *what kind of task*. To get complexity routing, express difficulty in route descriptions (e.g., "simple factual questions, greetings, short rewrites" vs. "deep multi-step analysis and planning").

---

## 2. Prerequisites

- Python + `pip install planoai` (CLI), Docker (Plano runs Envoy-based services).
- A **self-hosted routing model** for company data (see §4). By default Plano calls a **hosted** Plano-Orchestrator endpoint — override this.
- GPU recommended for production router serving with vLLM; Ollama + GGUF on CPU is fine for development.

**Download**

```bash
pip install planoai
planoai --help

# Router model (quantized, for Ollama/llama.cpp)
ollama pull hf.co/katanemo/Arch-Router-1.5B.gguf:Q4_K_M
# Full weights: https://huggingface.co/katanemo/Arch-Router-1.5B
# Larger orchestrator: https://huggingface.co/katanemo/Plano-Orchestrator-30B-A3B  (⚠️ check its license)
```

---

## 3. Configure — five models via your inference API

`plano_config.yaml` (v0.4.0 shape ✅; the custom `base_url` provider entries are ⚠️ — confirm the exact provider-prefix rules in *Supported Providers & Configuration*):

```yaml
version: v0.4.0

listeners:
  - name: egress_traffic
    type: model
    address: 0.0.0.0
    port: 12000
    timeout: 60s

overrides:
  llm_routing_model: plano/hf.co/katanemo/Arch-Router-1.5B.gguf:Q4_K_M   # self-hosted router

model_providers:
  # The router model (served by Ollama in dev; by vLLM in prod — see §4)
  - model: plano/hf.co/katanemo/Arch-Router-1.5B.gguf:Q4_K_M
    base_url: http://ollama:11434

  # Your five models, all behind YOUR inference API (OpenAI-compatible)
  - model: openai/fast-mini
    base_url: ${INFERENCE_API_BASE}          # ⚠️ verify base_url/path convention (with or without /v1)
    access_key: $INFERENCE_API_KEY
    default: true                             # used when no route matches
  - model: openai/general-small
    base_url: ${INFERENCE_API_BASE}
    access_key: $INFERENCE_API_KEY
  - model: openai/general-large
    base_url: ${INFERENCE_API_BASE}
    access_key: $INFERENCE_API_KEY
  - model: openai/code-specialist
    base_url: ${INFERENCE_API_BASE}
    access_key: $INFERENCE_API_KEY
  - model: openai/reasoning-frontier
    base_url: ${INFERENCE_API_BASE}
    access_key: $INFERENCE_API_KEY

routing_preferences:
  - name: small talk and quick facts
    description: greetings, thanks, short factual questions, simple rewrites and translations of short text
    models: [openai/fast-mini, openai/general-small]
  - name: everyday writing
    description: drafting emails, summaries of short documents, meeting notes, explanations of common concepts
    models: [openai/general-small, openai/general-large]
    selection_policy:
      prefer: cheapest
  - name: document analysis
    description: analyzing long documents, comparing policies or contracts, nuanced business writing
    models: [openai/general-large, openai/reasoning-frontier]
  - name: code generation
    description: generating, explaining, reviewing, or debugging code, SQL queries, scripts, infrastructure configuration
    models: [openai/code-specialist, openai/general-large]
  - name: complex reasoning
    description: multi-step reasoning, mathematics, quantitative analysis, planning, root-cause analysis
    models: [openai/reasoning-frontier, openai/general-large]

model_aliases:                      # let clients force a tier explicitly if needed
  fast:      {target: fast-mini}
  balanced:  {target: general-small}
  powerful:  {target: reasoning-frontier}

routing:
  route_on_user_only: true          # route per user turn; pin within agent loops
  session_ttl_seconds: 1800
  session_cache:
    type: redis
    url: redis://redis:6379

model_metrics_sources:
  - type: cost
    provider: models.dev             # schema selector; override url with YOUR catalog (same JSON shape)
    url: https://pricing.internal.example.com/models.json
    refresh_interval: 3600
```

**Pricing your custom aliases:** `cheapest` ordering needs prices. Host a small JSON endpoint in your infra that mimics the `models.dev` or DigitalOcean schema (documented in the LLM Routing guide) and point `url` to it. Use `model_aliases` under the metrics source if catalog keys differ from your model names.

**Writing good route descriptions** (from the docs' best practices):

- Names should match descriptions; descriptions specific and non-overlapping.
- Prefer **noun-centric** descriptors.
- Always include a broad **domain** route so the router has a fallback when the action is unclear.

---

## 4. Self-host the routing model

**Development — Ollama:**

```bash
ollama pull hf.co/katanemo/Arch-Router-1.5B.gguf:Q4_K_M
ollama serve                       # http://localhost:11434
curl http://localhost:11434/v1/models
```

**Production — vLLM (GPU):**

```bash
pip install vllm huggingface_hub
huggingface-cli download katanemo/Arch-Router-1.5B.gguf
SNAPSHOT_DIR=$(ls -d ~/.cache/huggingface/hub/models--katanemo--Arch-Router-1.5B.gguf/snapshots/*/ | head -1)

vllm serve ${SNAPSHOT_DIR}Arch-Router-1.5B-Q4_K_M.gguf \
  --host 0.0.0.0 --port 10000 \
  --load-format gguf \
  --chat-template ${SNAPSHOT_DIR}template.jinja \
  --tokenizer katanemo/Arch-Router-1.5B \
  --served-model-name Plano-Orchestrator \
  --gpu-memory-utilization 0.3 \
  --enable-prefix-caching
```

Then in config: `overrides.llm_routing_model: plano/Plano-Orchestrator` and a provider `- model: plano/Plano-Orchestrator` with `base_url: http://<router-host>:10000`.

---

## 5. Run and use

```bash
planoai up plano_config.yaml
planoai obs                        # observability console with per-request cost column
```

Client (Pattern B):

```python
import uuid
from openai import OpenAI

client = OpenAI(base_url="http://plano:12000/v1", api_key="EMPTY")
affinity = f"{tenant_id}:{conversation_id}"            # tenant-scoped key avoids collisions in Redis

resp = client.chat.completions.create(
    model="auto",            # ⚠️ docs show omitting/using a placeholder model to let the router decide;
                             #    check client-library guidance for your SDK version
    messages=messages,
    extra_headers={"X-Model-Affinity": affinity},
)
print(resp.model)
```

**Decision-only (Pattern A) — call the router model yourself.** Serve Arch-Router with vLLM, send the model card's routing prompt (route list + conversation), parse the JSON `{"route": "<name>"}` (or `{"route": "other"}`), and map route → model in your API. Use the **exact prompt template from the model card** — the authors state the model works best with it: https://huggingface.co/katanemo/Arch-Router-1.5B

---

## 6. Deploy to production

- **Kubernetes:** the repo ships manifests in `demos/llm_routing/model_routing_service/`:
  `vllm-deployment.yaml` (router model on GPU, with toleration for `nvidia.com/gpu:NoSchedule`), `plano-deployment.yaml`, `config_k8s.yaml` (points `llm_routing_model` at the in-cluster service).
- Mount the config ConfigMap with `--from-file=plano_config.yaml=config_k8s.yaml` and use **`subPath`** — otherwise K8s mounts a directory instead of a file.
- Model download ~1 min + load ~1–2 min; liveness probe `initialDelaySeconds: 180`.
- Multiple Plano replicas → Redis session cache so affinity is honored across replicas.
- Canonical deployment reference: https://docs.planoai.dev/resources/deployment.html

---

## 7. Tuning

1. Collect 300+ real conversations; label the route a human would choose.
2. Measure route accuracy; refine descriptions where routes get confused (split broad routes, sharpen nouns).
3. Add `selection_policy: cheapest` only on routes where candidates are truly equivalent.
4. Use model affinity for every chat session; consider `route_on_user_only` for tool-using flows.
5. Monitor cost per route in `planoai obs`; adjust pools.

---

## 8. Limitations ✅

- Router model is **not multimodal** (it can route text *about* images, not image bytes).
- Not for function-calling decisions (Plano has a separate function-calling model family).
- **Ignores system prompts** when routing — routing is based on conversation history.
- Difficulty is only as good as your route descriptions; it's not a difficulty predictor.
- Tool output must be sent as proper tool messages, or frameworks that echo results as user prose will re-route every step.

---

## 9. Official guides & links

- LLM Routing guide: https://docs.planoai.dev/guides/llm_router.html
- Quickstart: https://docs.planoai.dev/get_started/quickstart.html
- Supported providers: https://docs.planoai.dev/concepts/llm_providers/supported_providers.html
- Model aliases: https://docs.planoai.dev/concepts/llm_providers/model_aliases.html
- Configuration reference: https://docs.planoai.dev/resources/configuration_reference.html
- Deployment: https://docs.planoai.dev/resources/deployment.html
- Observability: https://docs.planoai.dev/guides/observability/observability.html
- Arch-Router model card: https://huggingface.co/katanemo/Arch-Router-1.5B · GGUF: https://huggingface.co/katanemo/Arch-Router-1.5B.gguf
- Paper "Arch-Router: Aligning LLM Routing with Human Preferences": https://arxiv.org/abs/2506.16655
- Tutorial (Daily Dose of DS, cost-reduction walkthrough with Plano): https://www.dailydoseofds.com/p/how-to-reduce-llm-costs-by-50-60-using-model-routing/
