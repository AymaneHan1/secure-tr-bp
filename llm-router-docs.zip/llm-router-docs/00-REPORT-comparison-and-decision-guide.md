# Report — Open-Source LLM Routing: Differences, Functionality, and When to Use Each

*Scope: open-source, self-hostable solutions only. Status as of October 2026.*
*Context: company-wide chatbot, 5 models, existing inference API that abstracts providers.*

---

## 1. Executive summary

1. **Routing pays off when your models differ a lot in price and most traffic is easy.** In an enterprise chatbot, a large share of messages (greetings, lookups, rewrites, short questions) do not need your most expensive model. Published results show the size of the prize: LMSYS's RouteLLM kept 95% of GPT-4 quality while sending only 14–26% of queries to GPT-4 (📊 48–75% cheaper than random routing), and NVIDIA reports a LangChain test with 74% lower cost routing 7% of calls to a frontier model at a 6% accuracy trade-off (📊).

2. **There are two kinds of "router" in the open-source world, and you need to know which you are buying:**
   - **Gateways/proxies** that sit in the request path and forward traffic (LiteLLM, vLLM Semantic Router, Plano, Switchyard, RouteLLM server, LLMRouter's OpenClaw server).
   - **Decision engines** — libraries or models that only answer "which model?" and leave the call to you (RouteLLM's routers, LLMRouter, Aurelio semantic-router, the NVIDIA complexity classifier, Arch-Router model, Switchyard's `libsy`).

3. **You already own a gateway** (your inference API). That changes the calculus: a second full gateway duplicates auth, logging, retries, and billing. For you the most natural architecture is a **decision-only routing service (sidecar)** that your API calls before each completion. Use a full gateway only if you specifically want its extra features (guardrails, semantic cache, dashboards) or want the fastest possible start.

4. **Recommendation (phased):**
   - **Phase 1 (weeks 1–3): LiteLLM Auto Router in shadow mode** — zero training, sub-millisecond heuristic, four tiers that map onto your five models, decision logs and savings accounting out of the box. Gets you data and a baseline fast.
   - **Phase 2 (weeks 3–8): Learned router on your own traffic** — label a sample of real conversations with an LLM judge, train a multi-model router (kNN/MLP, via LLMRouter or the playbook code), serve it as a sidecar or as a LiteLLM custom classifier plugin.
   - **Phase 3 (optional): vLLM Semantic Router** if you need routing + guardrails (PII, jailbreak) + semantic caching + Kubernetes-native ops in one platform.

5. **The hardest problems are not the classifier.** They are multi-turn context (a "yes" that approves a complex plan), prompt-cache invalidation when switching models mid-conversation, and measuring quality honestly. Every guide in this pack covers these.

---

## 2. Taxonomy — the six families of routing techniques

Every tool in this pack is a combination of these families. Understanding them is 80% of mastery.

| # | Family | How it decides | Training data needed | Added latency | Strengths | Weaknesses |
|---|---|---|---|---|---|---|
| 1 | **Rules & heuristics** | Keywords, regex, token count, code detection, "step by step" markers | None | < 1 ms | Transparent, free, deterministic | Brittle; misses paraphrases; can't judge real difficulty |
| 2 | **Semantic / intent routing** | Embed the query, compare to example utterances or route descriptions | A few examples per route | ~5–500 ms (depends on embedding model location) | Handles paraphrase; great for domain → specialist mapping | Measures *topic*, not *difficulty*; needs good examples |
| 3 | **Classifier (task/complexity)** | Small model predicts task type and/or difficulty score | Pretrained available; fine-tune optional | ~10–50 ms on GPU | Real difficulty signal; cheap to run | Generic training data ≠ your traffic; English-centric |
| 4 | **Learned quality/preference routers** | Predict per-model quality (or win-rate) for this query, pick best quality-per-cost | Your prompts × model outputs × quality labels | ~5–50 ms | Best cost/quality frontier when trained on your data | Needs a labeling pipeline; must retrain when models change |
| 5 | **LLM-as-router** | A small/medium LLM reads the request (and route descriptions) and picks | None (prompted) or fine-tuned (Arch-Router, Plano-Orchestrator) | 100 ms – 2 s | Understands context and nuance; easy to change policy in plain English | Slowest; costs tokens; can be inconsistent |
| 6 | **Cascades & escalation / bandits** | Try cheap model first, judge the answer, escalate if weak; or learn online from feedback (Thompson sampling) | Online feedback | Cascade adds a full extra call on escalation | Uses *actual* answer quality, not a prediction | Escalated requests pay twice and feel slower |

**Key insight:** families 1–3 predict difficulty from the **prompt**; family 4 predicts **outcome per model**; family 6 observes **actual outcomes**. Mature systems layer them: rules first (cheap, deterministic overrides), then a learned scorer, then escalation/feedback to correct mistakes.

---

## 3. The contenders at a glance

| Solution | What it is | License | Language | Maturity (Oct 2026) | Routing families | # models routed |
|---|---|---|---|---|---|---|
| **LiteLLM Auto Router** | Feature of the LiteLLM proxy/SDK | MIT core (separate commercial license for `enterprise/` folder) | Python | Beta feature in a very mature gateway | 1, 2, 5, 6 (Thompson sampling), + custom plugin | 4 tiers, each a model or pool |
| **vLLM Semantic Router** | Mixture-of-Models routing platform (Envoy ext_proc) | Apache-2.0 | Go/Python (+ ML models) | v0.4 "Hermes" stable (Sep 2026); fast-moving | 1, 2, 3, 4, plugins, fusion | Unlimited (decisions → model refs) |
| **Plano** (ex-Arch Gateway) + Arch-Router | Envoy-based AI proxy with preference routing | Proxy: open source (check LICENSE). Router model: custom Katanemo license | Rust/Python | Active (docs v0.4.39) | 5 (fine-tuned router LLM), aliases, cost/latency ordering | Unlimited routes, ordered model pools |
| **NVIDIA NeMo Switchyard** | Rust proxy + library for LLM traffic | Open source (check LICENSE) | Rust | Pre-alpha (APIs will change) | 5, 6 (escalation), stage signals, random A/B | Strong/weak tiers per route |
| **RouteLLM** (LMSYS) | Framework + pretrained routers | Apache-2.0 | Python | Research-grade, stable but slow-moving | 4 (MF, BERT, causal LLM, SW-Elo) | **2** (strong/weak) |
| **LLMRouter** (UIUC) | Library of 16+ trainable routers + CLI + server | MIT | Python | Active research library (paper Aug 2026) | 4, 5, multi-round, personalized | Unlimited |
| **Aurelio semantic-router** | Embedding-based decision layer library | MIT | Python | Stable (0.1.x; 0.2 in dev) | 2 | Unlimited routes |
| **NVIDIA Prompt Task & Complexity Classifier** | DeBERTa-v3-base classifier model | NVIDIA Open Model License (commercial use allowed; not OSI) | Model (PyTorch) | Stable v1.1 | 3 | You map scores → models |

---

## 4. Feature comparison matrix

Legend: ✅ built in · 🟡 partial / via extension · ❌ not available · — not applicable

| Capability | LiteLLM Auto | vLLM SR | Plano | Switchyard | RouteLLM | LLMRouter | Aurelio SR | NVIDIA classifier |
|---|---|---|---|---|---|---|---|---|
| OpenAI-compatible proxy | ✅ | ✅ | ✅ | ✅ (OpenAI + Anthropic + Responses) | ✅ | ✅ (OpenClaw server) | ❌ (library) | ❌ (model) |
| Decision-only mode (returns model name) | 🟡 test-routing endpoint / SDK | 🟡 route preview (mgmt API) | 🟡 call router model directly | ✅ `libsy` (Rust) | ✅ Python API | ✅ `--route-only` / Python | ✅ | ✅ |
| Complexity/difficulty routing | ✅ 7-dimension heuristic or LLM classifier | ✅ (signals) | 🟡 via route descriptions | ✅ classifier `p_solve` | ✅ win-rate score | ✅ | ❌ | ✅ |
| Intent/domain routing | ✅ keyword + semantic keywords | ✅ | ✅ (core strength) | 🟡 | ❌ | ✅ | ✅ (core strength) | ✅ task type |
| Train on your own data | 🟡 via custom plugin | 🟡 (ML algorithms, eval plane) | ❌ (no retraining by design) | 🟡 tunable routers | ✅ | ✅ (core strength) | 🟡 threshold fitting | 🟡 fine-tune yourself |
| Multi-turn context in decision | ✅ context window, assistant turns optional | ✅ (stateful routing since v0.3) | ✅ conversation-aware | ✅ stage router | ❌ (single prompt) | ✅ multi-round routers | ❌ | ❌ |
| Session affinity / cache pinning | ✅ | ✅ | ✅ `X-Model-Affinity` + Redis | ✅ | ❌ | ❌ | — | — |
| Escalation / cascade | 🟡 escalation keywords | 🟡 | ❌ | ✅ | ❌ | 🟡 AutoMix | ❌ | ❌ |
| Online learning (bandits) | ✅ Thompson sampling per tier | 🟡 | ❌ | ❌ | ❌ | 🟡 | ❌ | ❌ |
| Cost-aware ordering | ✅ savings accounting | ✅ | ✅ `prefer: cheapest/fastest` | ✅ metrics | ✅ threshold | ✅ cost in objective | ❌ | ❌ |
| Guardrails (PII, jailbreak) | 🟡 (many guardrails are Enterprise) | ✅ | ✅ filter chains | ❌ | ❌ | ❌ | 🟡 (as routes) | ❌ |
| Semantic cache | ✅ (LiteLLM caching) | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Dashboard / UI | ✅ admin UI | ✅ dashboard + Grafana/Jaeger | ✅ `planoai obs` console | 🟡 Prometheus + `/v1/stats` | 🟡 demo chat | ✅ Gradio + ComfyUI | ❌ | ❌ |
| Kubernetes story | ✅ Helm | ✅ Helm / CLI `--target k8s` | ✅ manifests | 🟡 binary/container | 🟡 DIY | 🟡 DIY | — | 🟡 DIY |
| Ops complexity | Low–medium | High | Medium | Low–medium | Low | Medium | Very low | Low |

---

## 5. Each solution in depth: functionality, strengths, weaknesses

### 5.1 LiteLLM Auto Router — *the pragmatic default*

**What it does.** A model alias (e.g., `smart-router`) that classifies each request into `SIMPLE / MEDIUM / COMPLEX / REASONING` and forwards it to the model (or pool) configured for that tier. Classifiers: a zero-cost heuristic scorer (token count, code presence, reasoning markers, technical terms, simple indicators, multi-step patterns, question complexity), an LLM classifier, keyword and semantic-keyword rules, or your own Python plugin. Extras: Thompson-sampling inside a tier pool, session affinity, prompt-cache-aware deployment pinning, context-window escalation, reasoning-effort ladders, and a per-request "savings vs. baseline" ledger.

**Strengths.** Fastest path to value; no training; extremely mature gateway underneath (100+ providers, budgets, virtual keys, fallbacks); the custom-classifier plugin lets you later drop in your own trained router without changing anything else.

**Weaknesses.** The heuristic scores *surface features* — it can be fooled (short but hard questions, long but easy pastes). Auto routing is labeled beta. Some governance features (SSO beyond 5 users, many built-in guardrails, custom classifier rubric replacement / custom tier definitions) require the Enterprise license. It's a second gateway next to yours.

**Use when:** you want a working router in days; you're fine adding a proxy hop; you want an easy path to plug your own model in later.

### 5.2 vLLM Semantic Router — *the platform*

**What it does.** A "programmable decision layer": it extracts **signals** from each request (domain, keywords, embeddings, complexity, user preference, etc.), evaluates **decisions** (prioritized rule sets) that select or *combine* models, and runs **plugins** (semantic caching, PII detection, jailbreak guard, hallucination detection). Runs as an Envoy external processor with a dashboard, Prometheus, Jaeger, Helm charts, an evaluation plane, and its own family of routing models (MoM models, Vela, Decision models) on Hugging Face.

**Strengths.** The most complete open-source routing platform; strong community (Red Hat, IBM, AMD, Hugging Face contributors); designed for heterogeneous compute (local + private + cloud); guardrails and caching in the same hop.

**Weaknesses.** Heavyweight (Envoy + router + dashboard + observability containers, GPU recommended for classifiers); configuration schema evolves quickly (v0.3 removed `vllm-sr init`, canonical YAML changed); learning curve is real.

**Use when:** you run Kubernetes, you want routing **and** safety **and** caching in one layer, you have platform engineers to own it.

### 5.3 Plano + Arch-Router / Plano-Orchestrator — *policy in plain English*

**What it does.** An Envoy-based AI proxy. Three routing modes: model-based (explicit), alias-based (`fast-model` → actual model), and preference-aligned: you write routes as natural-language descriptions (e.g., "code generation: generating new code snippets…") each with an ordered model pool; a routing LLM infers the domain/action of the conversation and picks the route. Per-route `selection_policy` can reorder candidates by live price or latency. Session pinning via `X-Model-Affinity` header (Redis-backed for multi-replica).

**Strengths.** Policy is human-readable and changes without retraining; adding a model = editing YAML; conversation-aware routing; cost/latency-aware ordering among equally capable models.

**Weaknesses.** Routes by *what kind of task*, not *how hard*; difficulty must be encoded in route descriptions. **By default it calls a hosted routing endpoint** — for a company chatbot you should self-host the router model (Ollama/vLLM). The 1.5B router model ships under a custom Katanemo license — get legal review. Router model ignores system prompts and isn't multimodal.

**Use when:** your five models are **specialists** (code, legal, creative, analysis…) more than **tiers**, and you want business owners to read and edit the routing policy.

### 5.4 NVIDIA NeMo Switchyard — *agent-workflow routing*

**What it does.** A Rust proxy/library that routes between a strong and weak tier per route: random A/B splits, an LLM classifier that estimates the probability the weak model solves the task (`p_solve`), a **stage router** that uses conversation signals (tool errors, progress, exploration) for multi-turn agents, and **escalation** (weak model first; a judge watches for trouble and escalates). Protocol translation between OpenAI Chat, Anthropic Messages, and OpenAI Responses. Being integrated into Kong AI Gateway and as a LiteLLM plugin (📊 per NVIDIA).

**Strengths.** Excellent for long agentic sessions; escalation is a genuinely different and robust strategy; low-overhead Rust; library mode never calls models itself (perfect for embedding in your API if it's in Rust).

**Weaknesses.** Pre-alpha; route-type names have already changed between versions; built around two tiers per route; telemetry is on unless you opt out.

**Use when:** your chatbot has agentic/tool-using flows; you want escalation rather than up-front prediction; you can tolerate API churn.

### 5.5 RouteLLM — *the reference learned router*

**What it does.** Pretrained routers (matrix factorization, BERT classifier, causal-LLM classifier, similarity-weighted Elo) that output the probability that the strong model beats the weak model on this prompt; a threshold converts that to a decision. Ships an OpenAI-compatible server, a calibration tool to hit a target % of strong-model calls, and an evaluation harness (MMLU, GSM8K, MT-Bench).

**Strengths.** Well-studied (peer-reviewed); simple mental model; the win-rate score is a usable **continuous difficulty score** — with several calibrated thresholds you can map it to 5 tiers.

**Weaknesses.** Strictly two models; routers trained in 2024 on the GPT-4 vs. Mixtral pair; `mf` and `sw_ranking` need an OpenAI embedding key; no multi-turn awareness; low maintenance cadence.

**Use when:** you want a strong baseline or a proven difficulty scorer; as a component inside your own sidecar.

### 5.6 LLMRouter (UIUC) — *the router workshop*

**What it does.** One library, 16+ routing algorithms (kNN, SVM, MLP, MF, Elo, RouterDC, AutoMix, Hybrid-LLM, GraphRouter, causal-LM router, Router-R1 multi-round, personalized GNN routers…), a data-generation pipeline (query → all candidate models → scored routing data), unified `train / infer / chat / serve` CLI, a plugin system for custom routers, an OpenAI-compatible server, and the xRouteBench benchmark. Their paper reports learned routers beating the strongest single fixed model by 14.6% (relative) 📊.

**Strengths.** The best place to *train and compare* multi-model routers on your own data; route-only inference; MIT.

**Weaknesses.** Research codebase (Python 3.10, pinned heavy deps for some routers); the default data pipeline is benchmark-oriented — you adapt it to your logs; production serving hardening is on you.

**Use when:** Phase 2 — you have labeled traffic and want the best multi-model learned router.

### 5.7 Aurelio semantic-router — *the intent switchboard*

**What it does.** Define `Route`s by example utterances; embed them; route incoming queries by vector similarity in milliseconds; optional hybrid dense+sparse; threshold tuning; local or hosted encoders.

**Strengths.** Tiny, fast, MIT, deterministic; great for "if HR/IT/legal topic → model X" and for guardrail routes (off-topic, jailbreak-ish).

**Weaknesses.** Measures similarity to examples, not difficulty; quality depends on your utterances.

**Use when:** you need domain/intent → specialist mapping inside your own sidecar.

### 5.8 NVIDIA Prompt Task & Complexity Classifier — *the difficulty sensor*

**What it does.** One forward pass returns the task type (11 classes, e.g., Open QA, Closed QA, Code Generation, Summarization, Chatbot) plus six complexity dimensions (creativity, reasoning, contextual knowledge, domain knowledge, constraints, few-shot count) and an overall weighted score.

**Strengths.** Ready-to-use difficulty + task signal; commercially usable; fast on GPU.

**Weaknesses.** Trained on ~4k English prompts; 512-token default window; the overall score weights creativity highest (35%), which is *not* the same as "needs an expensive model" — use the individual dimensions, not just the overall score.

**Use when:** you're building a sidecar and want a strong pretrained feature extractor (alone or as input features to your learned router).

---

## 6. When to use which — decision guide

### 6.1 Decision tree

```
Do you need the router to also do guardrails + semantic cache + K8s-native ops?
├─ YES → vLLM Semantic Router
└─ NO
   │
   Are your 5 models mainly SPECIALISTS (by domain/task) rather than TIERS (by capability/cost)?
   ├─ YES → Is routing policy owned by non-ML people who want plain-English rules?
   │        ├─ YES → Plano (self-host the router model)
   │        └─ NO  → Aurelio semantic-router (+ rules) in your own sidecar
   └─ NO (tiers)
      │
      Do you want results in days with zero training?
      ├─ YES → LiteLLM Auto Router (shadow first)
      └─ NO, I want the best cost/quality curve on my traffic
         │
         Is your workload agentic / long tool-using sessions?
         ├─ YES → Switchyard (stage/escalation) — or LiteLLM + session affinity
         └─ NO  → Learned router: LLMRouter (multi-model) or RouteLLM (pairs)
                  + NVIDIA classifier features, served as a decision sidecar
```

### 6.2 Scenario table

| Scenario | Best choice | Runner-up |
|---|---|---|
| "Ship something this sprint" | LiteLLM Auto Router (heuristic) | Plano with aliases + 3–4 preference routes |
| "Maximum savings at fixed quality on our traffic" | Learned router (playbook 01 / LLMRouter) | RouteLLM score with multi-threshold calibration |
| "Our models are domain specialists" | Plano | Aurelio semantic-router |
| "Strict data residency / no external calls" | Any self-hosted; avoid hosted router endpoints (Plano default), opt out of Switchyard telemetry | — |
| "Agents with tools, 20+ turns per task" | Switchyard stage/escalation | LiteLLM with `session_affinity` + `classification_mode: user_turn` |
| "Need PII/jailbreak filtering in the same layer" | vLLM Semantic Router | Plano filter chains |
| "Platform team on Kubernetes, many apps share models" | vLLM Semantic Router | LiteLLM (Helm) |
| "We only have 2 models that matter (cheap vs. frontier)" | RouteLLM | Switchyard classifier route |
| "We want to compare many algorithms scientifically" | LLMRouter + RouterArena | RouteLLM eval harness |

### 6.3 What each one costs you to operate

| Solution | Infra footprint | People skills | Time to first value |
|---|---|---|---|
| LiteLLM Auto | 1 container (+ Postgres for spend/savings, Redis for multi-replica) | Backend/DevOps | 1–3 days |
| vLLM SR | Envoy + router + dashboard + Prometheus/Jaeger; GPU recommended | Platform + ML | 1–3 weeks |
| Plano | Proxy + router model server (GPU recommended for vLLM; CPU OK for GGUF via Ollama in dev) | Backend/DevOps | 2–5 days |
| Switchyard | 1 binary/container | Backend (Rust helpful) | 1–3 days |
| RouteLLM | 1 Python service | ML-literate backend | 2–5 days |
| LLMRouter | Training env (GPU optional) + serving | ML engineer | 2–6 weeks (incl. labeling) |
| Aurelio SR | In-process library + embedding model | Backend | 1–2 days |
| NVIDIA classifier | Small GPU or CPU service | ML-literate backend | 1–3 days |

---

## 7. Recommended architecture for your ecosystem

Because your inference API already abstracts providers, keep it as the **single egress point** (auth, quotas, logging, billing stay where they are) and add routing as a **decision**:

```
           ┌────────────────────────── your inference API ──────────────────────────┐
client ──▶ │ 1. receive request (model="auto")                                      │
           │ 2. POST /route  ───────────────▶ ┌──────── routing sidecar ────────┐   │
           │                                  │ rules → classifier → learned    │   │
           │ 3. ◀── {"model":"general-small", │ scorer → policy (λ·cost)        │   │
           │        "reason":..., "v":"r12"}  └─────────────────────────────────┘   │
           │ 4. call provider for chosen model (existing code path)                 │
           │ 5. log decision + usage + cost + feedback                              │
           └────────────────────────────────────────────────────────────────────────┘
```

- **Phase 1:** run LiteLLM Auto Router in **shadow** (its decision is logged, not used) — or call its test-routing endpoint — to get a baseline distribution and savings estimate.
- **Phase 2:** build the sidecar per [playbook 01](03-playbooks/01-build-your-own-router.md): rules + NVIDIA classifier features + embedding-based learned scorer trained on your labeled traffic; calibrate λ to your budget.
- **Alternative to the sidecar:** keep LiteLLM in the path and load your trained model as a **custom classifier plugin** — you get its session affinity, savings accounting and UI for free.

Full integration patterns, contracts, timeouts and failure modes are in [`01-fundamentals/02-integration-architecture.md`](01-fundamentals/02-integration-architecture.md).

---

## 8. Risks and how each solution handles them

| Risk | Why it matters | Mitigation |
|---|---|---|
| **Under-routing** (hard query → cheap model) | Bad answers erode trust | Escalation path, "regenerate with better model" button, conservative threshold on high-stakes topics (legal, finance, HR) |
| **Context-blind routing** | "Yes, do it" after a complex plan routed to cheapest tier | Include prior turns in classification (LiteLLM context window, Plano conversation routing, Switchyard stage router) |
| **Cache thrash** | Switching models mid-session loses provider prompt cache; can make savings negative | Session affinity / per-user-turn classification; measure savings net of cache effects (LiteLLM does) |
| **Silent drift** | New use cases appear; router trained on old traffic | Weekly sample re-labeling, distribution dashboards, retrain cadence |
| **Router outage/latency** | Router becomes a single point of failure | Strict timeout (e.g., 50–100 ms), fall back to a default mid-tier model, never fail the request |
| **Licensing** | Some router *models* aren't OSI-licensed | Arch-Router: Katanemo license; NVIDIA classifier: NVIDIA Open Model License; LiteLLM `enterprise/` folder: commercial. Everything else here: MIT/Apache |
| **Data leakage** | Router calls hosted endpoints or sends telemetry | Self-host router models; opt out of telemetry (`SWITCHYARD_TELEMETRY_OPT_OUT=1`); keep embeddings in-house |

---

## 9. Bottom line

- **Start:** LiteLLM Auto Router, shadow mode, one week of data.
- **Win:** a learned router trained on *your* labeled traffic, served as a decision sidecar (or LiteLLM plugin).
- **Scale/platform:** vLLM Semantic Router if routing becomes shared infrastructure with guardrails and caching.
- **Specialists:** Plano (or Aurelio) when the question is "which kind of task" rather than "how hard".
- **Agents:** Switchyard's stage/escalation ideas, even if you implement them in your own stack.

Next: read [`01-fundamentals/01-routing-concepts.md`](01-fundamentals/01-routing-concepts.md).
