# 04 — Resources: Downloads, Docs, Models, Papers, Tutorials

*Links collected October 2026. If a link moves, search the project name on GitHub or Hugging Face.*

---

## 1. Install cheat sheet

| Solution | Download / install | Run |
|---|---|---|
| LiteLLM | `docker pull ghcr.io/berriai/litellm:main-stable` (pin a version) · `pip install 'litellm[proxy]'` | `litellm --config config.yaml` (port 4000) |
| vLLM Semantic Router | `curl -fsSL https://vllm-sr.ai/install.sh \| bash -s -- --channel stable` · `pip install vllm-sr` | `vllm-sr serve --config config.yaml` (8899 / dashboard 8700) |
| Plano | `pip install planoai` · router model: `ollama pull hf.co/katanemo/Arch-Router-1.5B.gguf:Q4_K_M` | `planoai up plano_config.yaml` (port 12000) |
| NeMo Switchyard | `uv tool install "nemo-switchyard[cli,server]"` · `cargo install --locked switchyard-server` | `switchyard serve -c routes.yaml --port 4000` |
| RouteLLM | `pip install "routellm[serve,eval]"` | `python -m routellm.openai_server --routers mf …` (port 6060) |
| LLMRouter | `pip install llmrouter-lib` · `git clone https://github.com/ulab-uiuc/LLMRouter` | `llmrouter train/infer/chat/serve …` |
| Aurelio semantic-router | `pip install -U semantic-router` | in-process library |
| NVIDIA classifier | `pip install torch transformers huggingface_hub` + model card code | your FastAPI sidecar |

---

## 2. Repositories (source & downloads)

| Project | Repo | License |
|---|---|---|
| LiteLLM | https://github.com/BerriAI/litellm · images: https://github.com/berriai/litellm/pkgs/container/litellm | MIT (+ commercial `enterprise/` folder) |
| vLLM Semantic Router | https://github.com/vllm-project/semantic-router | Apache-2.0 |
| Plano | https://github.com/katanemo/plano | open source (see LICENSE) |
| NeMo Switchyard | https://github.com/NVIDIA-NeMo/Switchyard | open source (see LICENSE) |
| RouteLLM | https://github.com/lm-sys/RouteLLM | Apache-2.0 |
| LLMRouter | https://github.com/ulab-uiuc/LLMRouter | MIT |
| Aurelio semantic-router | https://github.com/aurelio-labs/semantic-router | MIT |
| NeMo Curator (batch prompt classification) | https://github.com/NVIDIA-NeMo/Curator | see repo |
| Anyscale LLM router tutorial | https://github.com/anyscale/llm-router | see repo |
| RouterArena | https://github.com/RouteWorks/RouterArena | see repo |
| RouteProfile | https://github.com/ulab-uiuc/RouteProfile | see repo |
| Router-R1 | https://github.com/ulab-uiuc/Router-R1 | see repo |
| NVIDIA LLM Router blueprint (deprecated, historical) | https://github.com/NVIDIA-AI-Blueprints/llm-router | see repo |

---

## 3. Official documentation

**LiteLLM**
- Auto Routing: https://docs.litellm.ai/docs/proxy/auto_routing
- Semantic Auto Router (deprecated): https://docs.litellm.ai/docs/proxy/auto_routing_semantic
- Routing plugins: https://docs.litellm.ai/docs/routing_plugins
- `lite autoroute` CLI: https://docs.litellm.ai/docs/learn/autorouter_cli
- Docs index for LLM agents: https://docs.litellm.ai/llms.txt
- Auto Router discussion/feedback: https://github.com/BerriAI/litellm/discussions/32168
- Open-source vs. enterprise policy: https://github.com/BerriAI/litellm/discussions/2023

**vLLM Semantic Router**
- Docs: https://vllm-sr.ai · Installation: https://vllm-sr.ai/docs/installation/ · Configuration: https://vllm-sr.ai/docs/installation/configuration/ · Kubernetes: https://vllm-sr.ai/docs/installation/k8s/ · Agent harness: https://vllm-sr.ai/docs/installation/agent-harness/
- Playground: https://app.vllm-sr.ai/playground
- PyPI: https://pypi.org/project/vllm-sr/

**Plano**
- Docs: https://docs.planoai.dev · Quickstart: https://docs.planoai.dev/get_started/quickstart.html · LLM Routing: https://docs.planoai.dev/guides/llm_router.html · Providers: https://docs.planoai.dev/concepts/llm_providers/supported_providers.html · Config reference: https://docs.planoai.dev/resources/configuration_reference.html · Deployment: https://docs.planoai.dev/resources/deployment.html

**Switchyard**
- Repo docs: `docs/getting_started.md`, `docs/core_concepts.md`, `docs/routing_algorithms/` (overview, llm_classifier, stage_router, escalation_router, random)
- NVIDIA blog: https://developer.nvidia.com/blog?p=120999

**RouteLLM** — README (server, calibration, eval): https://github.com/lm-sys/RouteLLM · local models: https://github.com/lm-sys/RouteLLM/blob/main/examples/routing_to_local_models.md

**LLMRouter** — docs: https://ulab-uiuc.github.io/LLMRouter/ · PyPI: https://pypi.org/project/llmrouter-lib/

**Aurelio semantic-router** — docs: https://docs.aurelio.ai/semantic-router/get-started/introduction · encoders: https://docs.aurelio.ai/semantic-router/user-guide/components/encoders

**NVIDIA classifier** — NeMo Curator API: https://docs.nvidia.com/nemo/curator/0.25.7/apidocs/classifiers/classifiers.prompt_task_complexity.html

---

## 4. Models (Hugging Face)

| Model | Use | License |
|---|---|---|
| `nvidia/prompt-task-and-complexity-classifier` — https://huggingface.co/nvidia/prompt-task-and-complexity-classifier | Task + 6 complexity dimensions | NVIDIA Open Model License |
| `katanemo/Arch-Router-1.5B` — https://huggingface.co/katanemo/Arch-Router-1.5B (GGUF: https://huggingface.co/katanemo/Arch-Router-1.5B.gguf) | Preference (domain/action) routing LLM | Katanemo research license |
| `katanemo/Plano-Orchestrator-30B-A3B` — https://huggingface.co/katanemo/Plano-Orchestrator-30B-A3B | Larger routing/orchestration model used by Plano | check card |
| RouteLLM routers — https://huggingface.co/routellm | MF / BERT / causal-LLM routers | check cards |
| vLLM-SR models — https://huggingface.co/vllm-sr (and https://huggingface.co/llm-semantic-router) | MoM classifiers (domain, PII, jailbreak, factuality…), Vela routing models, Decision models (collection: https://huggingface.co/collections/vllm-sr/decision-20) | check cards |
| Embedding models for your own router | `BAAI/bge-small-en-v1.5`, `intfloat/multilingual-e5-small`, `Qwen/Qwen3-Embedding-0.6B` (used by xRouteBench) | check cards |

---

## 5. Datasets & benchmarks

- Chatbot Arena human preferences (RouteLLM training): https://huggingface.co/datasets/lmsys/lmsys-arena-human-preference-55k
- xRouteBench: https://huggingface.co/datasets/ulab-ai/xRouteBench
- RouterArena leaderboard: https://routeworks.github.io/ · paper: https://arxiv.org/abs/2510.00202 (ICLR 2026)

---

## 6. Papers (reading order for mastery)

1. **RouteLLM: Learning to Route LLMs with Preference Data** — https://arxiv.org/abs/2406.18665 (foundational; APGR/CPT metrics)
2. **Hybrid LLM: Cost-Efficient and Quality-Aware Query Routing** (ICLR 2024) — https://arxiv.org/abs/2404.14618
3. **AutoMix: Automatically Mixing Language Models** (cascades, NeurIPS 2024) — https://arxiv.org/abs/2310.12963
4. **RouterDC: Query-Based Router by Dual Contrastive Learning** (NeurIPS 2024) — https://arxiv.org/abs/2409.19886
5. **GraphRouter** (ICLR 2025) — https://arxiv.org/abs/2410.03834
6. **Arch-Router: Aligning LLM Routing with Human Preferences** — https://arxiv.org/abs/2506.16655
7. **Router-R1: Multi-Round Routing and Aggregation via RL** (NeurIPS 2025) — https://arxiv.org/abs/2506.09033
8. **When to Reason: Semantic Router for vLLM** — https://arxiv.org/abs/2510.08731
9. **Category-Aware Semantic Caching for Heterogeneous LLM Workloads** — https://arxiv.org/abs/2510.26835
10. **RouterArena: An Open Platform for Comprehensive Comparison of LLM Routers** — https://arxiv.org/abs/2510.00202
11. **LLMRouter: Unified Infrastructure for Developing, Evaluating, and Deploying LLM Routers** (Aug 2026) — https://arxiv.org/abs/2608.06867
12. Personalized routing: GMTRouter https://arxiv.org/abs/2511.08590 · PersonalizedRouter https://arxiv.org/abs/2511.16883 · FusionFactory https://arxiv.org/abs/2507.10540
13. vLLM-SR vision paper (Workload-Router-Pool architecture): https://vllm-sr.ai/vision-paper · white paper (signal-driven decision routing): https://vllm-sr.ai/white-paper/

---

## 7. Tutorials, blogs, and hands-on guides

**Hands-on**
- Switchyard step-by-step (random → classifier → stage → escalation), KDnuggets, Sept 2026: https://www.kdnuggets.com/switchyard-nvidias-open-source-routing-library
- Plano cost-routing walkthrough ("reduce LLM costs by 50–60%"), Daily Dose of DS: https://www.dailydoseofds.com/p/how-to-reduce-llm-costs-by-50-60-using-model-routing/
- LiteLLM proxy Docker setup (15-min guide): https://techsy.io/blog/litellm-proxy-setup-guide
- Anyscale: building an LLM router (fine-tune a causal-LLM classifier; offline eval with RouteLLM): https://github.com/anyscale/llm-router
- NVIDIA: deploying the (now-deprecated) LLM Router blueprint — useful for task vs. complexity routing ideas: https://developer.nvidia.com/blog/deploying-the-nvidia-ai-blueprint-for-cost-efficient-llm-routing/

**Project blogs (architecture deep dives)**
- RouteLLM launch: https://lmsys.org/blog/2024-07-01-routellm/
- vLLM-SR: v0.1 Iris https://blog.vllm.ai/2026/01/05/vllm-sr-iris.html · Signal-Decision architecture https://blog.vllm.ai/2025/11/19/signal-decision.html · v0.3 Themis https://vllm-sr.ai/blog/v0.3-vllm-sr-themis-release/ · v0.4 Hermes https://vllm-sr.ai/blog/v0.4-vllm-sr-hermes-release/ · Fusion https://vllm-sr.ai/blog/vllm-sr-fusion-api/ · Mixture-of-Models https://vllm-sr.ai/blog/vllm-sr-new-chapter-mom/ · Vela 2.0 https://vllm-sr.ai/blog/vela-2-0-open-foundation-routing-models/ · Decision models https://vllm-sr.ai/blog/decision-models/ · Hallucination detection https://blog.vllm.ai/2025/12/14/halugate.html · Extensible LoRA https://blog.vllm.ai/2025/10/27/semantic-router-modular.html

**Landscape / comparisons** (vendor-written; read critically)
- Holori — best LLM routers 2026: https://holori.com/best-llm-routers/
- Pinggy — LLM routers & OpenRouter alternatives: https://pinggy.io/amp/blog/best_ai_llm_routers_openrouter_alternatives/
- FutureAGI — routers & load balancers compared: https://futureagi.com/blog/best-llm-routers-load-balancers-2026/

---

## 8. Communities

- vLLM Slack `#semantic-router` (community meetings 2nd and 4th Wednesday monthly)
- LLMRouter Slack (link in repo README)
- LiteLLM GitHub Discussions
- RouterArena PRs for leaderboard submissions
