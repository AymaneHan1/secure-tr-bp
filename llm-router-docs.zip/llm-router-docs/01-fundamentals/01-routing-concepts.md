# 01 — Routing Concepts: Everything You Need to Reason About Routers

This chapter is tool-agnostic. Once you understand it, every router in `02-guides/` is just a particular combination of these ideas.

---

## 1. The problem, formally

For each request *x* you must choose one model *m* from your set *M* = {fast-mini, general-small, general-large, code-specialist, reasoning-frontier}.

Each choice has:

- **Quality** *q(x, m)* — how good the answer is (unknown until you run it).
- **Cost** *c(x, m)* — roughly `input_tokens × in_price(m) + output_tokens × out_price(m)`.
- **Latency** *t(x, m)* — time to first token and total time.

A router is a function *r(x) → m* that tries to maximize total quality under a budget, or minimize cost at a target quality. The standard objective used by most learned routers:

```
choose m* = argmax_m [ q̂(x, m) − λ · ĉ(x, m) ]
```

- `q̂` = predicted quality, `ĉ` = predicted cost, `λ` = how much you care about money.
- `λ = 0` → always the best model. `λ → ∞` → always the cheapest.
- Sweeping λ traces a **cost–quality curve** (the "Pareto frontier"). Your business picks a point on it.

Two-model routers (RouteLLM) simplify this to: *P(strong beats weak | x) > threshold → strong*. The threshold plays the role of λ.

---

## 2. Signals a router can use

| Signal | Example | Cost to compute | What it predicts well |
|---|---|---|---|
| Length | tokens in last user message, total context | free | context-window needs; weakly correlated with difficulty |
| Lexical markers | "step by step", "prove", "debug", code fences, SQL keywords | free | reasoning/code intent |
| Conversation state | turn number, previous model used, tool errors, user said "that's wrong" | free | escalation needs, affinity |
| Metadata | user team, app, tenant plan, channel | free | policy routing (e.g., legal team → never cheapest) |
| Embedding of the query | 384–1024-dim vector | 2–20 ms local | topic/domain; nearest past examples |
| Classifier outputs | task type, complexity dimensions | 10–50 ms GPU | difficulty, task |
| Router LLM judgment | "this is code generation in finance domain" | 100 ms–2 s | nuanced intent, conversation context |
| Observed outcome | cheap model's answer quality judged | a full extra call | true quality (cascades) |
| User feedback | thumbs, regenerate, copy, follow-up rephrasing | free, delayed | long-run quality per model (bandits, retraining) |

**Practical rule:** combine free signals (rules, metadata) as hard overrides, use one fast learned signal (embedding/classifier) as the main decision, and use expensive signals (LLM judge, cascade) only where the stakes justify them.

---

## 3. Defining "quality" — the part most teams get wrong

You cannot train or evaluate a router without a quality definition. Options, from cheapest to most faithful:

1. **Proxy benchmarks** (MMLU, GSM8K, MT-Bench) — what RouteLLM was evaluated on. Cheap but may not reflect your chatbot.
2. **LLM-as-judge on your traffic** — the strongest model grades each candidate answer 1–10 against a rubric (correctness, completeness, instruction following, tone). Scales well; validate against humans on 100–300 samples.
3. **Pairwise preference** — judge (or human) picks the better of two answers. More reliable than absolute scores; what RouteLLM's training data (Chatbot Arena) uses.
4. **Online implicit feedback** — regenerations, thumbs-down, follow-ups like "that's wrong", abandonment. Noisy but real.
5. **Human evaluation** — gold standard for a small audited set.

**Label design that works for 5-model routing:** for each prompt, run all 5 models, judge each answer, then label the prompt with the **cheapest model whose score is within δ of the best score** (e.g., δ = 1 point on a 10-point scale). This directly encodes "good enough at lowest cost".

---

## 4. Cost math you should do before building anything

Estimate the savings ceiling with your own numbers:

```
current_cost   = Σ requests × cost(default_model)
oracle_cost    = Σ requests × cost(cheapest model that's good enough)   # from a labeled sample
max_savings    = 1 − oracle_cost / current_cost
realistic      ≈ 50–80% of max_savings for a good learned router
```

Also include:

- **Router overhead**: classifier GPU, or tokens for an LLM classifier on every request.
- **Escalation cost**: in cascades, escalated requests pay for both calls.
- **Cache effects**: providers discount cached prompt prefixes; switching model mid-conversation forfeits that discount and can pay a cache-write premium. LiteLLM's savings ledger explicitly reports *negative* savings when this happens.

If most of your traffic already goes to a mid-priced model and your expensive model is rarely used, routing gains are smaller — the big wins come from sending easy traffic *down* from an expensive default.

---

## 5. Multi-turn conversations — the #1 practical trap

A chatbot is not a stream of independent prompts.

**Trap A — the "yes" problem.** Assistant: "Here is a 7-step migration plan. Shall I write the scripts?" User: "yes". A prompt-only router sees "yes" → `fast-mini`. Fixes:
- Classify with the last N turns as context (LiteLLM `classifier_context_window_size`, optional assistant turns).
- Route per **user turn**, not per API call (Plano `route_on_user_only`, LiteLLM `classification_mode: user_turn`).
- Rule: short affirmation after a long assistant turn → keep previous model.

**Trap B — cache thrash.** Each switch between models discards the provider-side prompt cache for the long shared prefix (system prompt + history). Fixes: session affinity (pin first-turn model for a TTL), or allow only **upgrades** within a session, never downgrades.

**Trap C — incompatible history.** Some model-specific artifacts (e.g., reasoning/"thinking" blocks) can't be replayed to another provider's model. Session pinning avoids provider errors.

**Trap D — tool-using agents.** Tool results look like user messages to naive routers. Make sure tool outputs use the proper tool role so routers that skip tool turns work correctly (Plano and LiteLLM both rely on this).

---

## 6. Router families in more depth

### 6.1 Rules and heuristics
- Deterministic, auditable, free. Use for: compliance overrides ("legal team → general-large minimum"), obvious cases (greetings → fast-mini), and guard conditions (context > 100k tokens → model with large window).
- LiteLLM's heuristic scorer is a well-engineered example: weighted dimensions (token count, code presence, reasoning markers, technical terms, simple indicators, multi-step patterns, question complexity) mapped to tier boundaries.

### 6.2 Semantic routing
- Define routes by examples ("utterances") or descriptions. Query embedding → nearest route above a threshold → model.
- Excellent for **specialist** mapping (code → code-specialist). Weak for difficulty: "explain recursion" and "prove this recursive algorithm terminates" are semantically close but differ greatly in difficulty.

### 6.3 Classifiers
- A small encoder model (BERT/DeBERTa) predicts task and/or difficulty. Fast, cheap. Generic pretrained ones (NVIDIA's) are a great feature source; fine-tuned ones on your labels are better.

### 6.4 Learned per-model quality predictors
- Predict `q̂(x, m)` for each model (matrix factorization, MLP, kNN over embeddings, graph networks). Then apply the λ objective.
- **kNN** is a remarkably strong baseline: find the k most similar labeled past prompts and average each model's observed score.
- Must be retrained when you swap a model (or use methods that represent models by profiles/embeddings — GraphRouter, RouteProfile in LLMRouter, or Arch-Router's description-based approach).

### 6.5 LLM-as-router
- Prompted or fine-tuned LLM chooses a route given route descriptions and conversation. Arch-Router-1.5B (Qwen2.5-1.5B fine-tune) and Plano-Orchestrator are fine-tuned examples; NVIDIA's blueprint used Qwen3-1.7B for intent classification.
- Best when the policy is semantic and changes often; slowest family.

### 6.6 Cascades, escalation, and bandits
- **Cascade**: cheap model answers → judge (or self-confidence) → escalate if poor. True quality signal, but escalations cost twice and add latency (bad for streaming chat unless you judge before streaming).
- **Escalation over a session** (Switchyard): keep the weak model while it's doing fine; escalate when the judge sees sustained trouble.
- **Bandits** (Thompson sampling): within a tier's pool, learn online which model gets better feedback. LiteLLM supports this per tier with `adaptive: true`.

---

## 7. Evaluation vocabulary (used throughout this pack)

| Term | Meaning |
|---|---|
| **Strong-call %** | Share of requests sent to the expensive model(s) |
| **Quality retained** | Router quality ÷ always-best-model quality |
| **Cost saved** | 1 − router cost ÷ always-best-model cost (or ÷ current baseline) |
| **APGR** | Average Performance Gap Recovered — how much of the gap between weak-only and strong-only quality the router recovers (RouteLLM paper) |
| **CPT(x%)** | Call-Performance Threshold — strong-call % needed to reach x% of strong-model performance (RouteLLM paper uses CPT(50%), CPT(80%)) |
| **Oracle router** | Hypothetical router that always picks the cheapest good-enough model — your upper bound |
| **Shadow mode** | Router decides and logs, but the old path still serves the user |

Details and code in [`03-playbooks/02-evaluation-and-benchmarking.md`](../03-playbooks/02-evaluation-and-benchmarking.md).

---

## 8. Checklist: questions to answer before choosing a tool

1. Are my 5 models **tiers** (same job, different power) or **specialists** (different jobs)? Usually a mix.
2. What's my current cost split by model, and what's the oracle savings ceiling on a labeled sample?
3. What's my latency budget for the routing decision? (Chat UX: aim < 50 ms p95 for the decision.)
4. Do I need multi-turn awareness and session pinning? (Chatbot: yes.)
5. Who owns the policy — ML engineers (learned router) or business/platform owners (readable rules/preferences)?
6. Must everything stay in-house? (Then self-host every router model; no hosted router endpoints.)
7. Do I want a second gateway, or a decision service behind my existing API? (See next chapter.)

Next: [`02-integration-architecture.md`](02-integration-architecture.md).
