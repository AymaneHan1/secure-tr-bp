# 02 — Integration Architecture: Plugging a Router Into Your Inference API

You already have an inference API that abstracts all providers. There are four ways to add routing. Each guide in `02-guides/` says which patterns it supports.

---

## Pattern A — Decision-only sidecar (recommended for you)

```
client ──▶ Inference API ──(1) POST /route {messages, meta}──▶ Router sidecar
                │          ◀─(2) {"model": "general-small", ...}──┘
                └──(3) existing provider call for the chosen model ──▶ provider
```

- Your API stays the single egress point: auth, quotas, retries, logging, billing untouched.
- The router can be anything: a rule engine, Aurelio semantic-router, the NVIDIA classifier, a RouteLLM/LLMRouter model, a call to Arch-Router served by vLLM, or LiteLLM's test-routing endpoint.
- Easy to run in **shadow mode** (call router, log answer, ignore it).

**Supported natively by:** RouteLLM (Python), LLMRouter (`--route-only`, Python API), Aurelio semantic-router, NVIDIA classifier, Switchyard `libsy` (Rust), Arch-Router model (raw). Partially: LiteLLM (`POST /auto_router/test_routing` — a preview endpoint that classifies without calling the model), vLLM SR (`route preview` on its management API, port 8080). For LiteLLM/vLLM SR, treat preview endpoints as **shadow/evaluation** tools; for production decisions prefer Pattern B or C, or check their docs for a supported decision API.

## Pattern B — Router gateway in front of your API

```
client ──▶ Router gateway (LiteLLM / vLLM SR / Plano / Switchyard) ──▶ Inference API (as an OpenAI-compatible "provider") ──▶ providers
```

- Clients send `model: "smart-router"` (or `vllm-sr/auto`, or no model for Plano).
- The gateway's "backends" are **your API's model aliases**: same base URL, different `model` value.
- Pros: zero code change in your API; you get the gateway's features (session affinity, dashboards, savings).
- Cons: extra network hop (typically single-digit ms in-cluster); two places with logs/auth; clients must point at the gateway.

## Pattern C — Router gateway behind your API

```
client ──▶ Inference API ──(model="auto")──▶ Router gateway ──▶ Inference API internal endpoint per model / or providers directly
```

- Your API treats the router as just another provider called `auto`.
- Useful if clients must keep talking to your API, but you want the gateway's routing.
- Watch for **loops**: the gateway must call an internal endpoint of your API that bypasses the `auto` route (or call providers directly).

## Pattern D — Embedded library

```
Inference API process ── import router ──▶ decide in-process ──▶ provider call
```

- Lowest latency, no extra service. Couples deploys and dependencies (PyTorch in your API image, GPU needs).
- Fits: Aurelio semantic-router, rules, small sklearn models, LiteLLM Python SDK `Router`, Switchyard `libsy` (if your API is Rust).

### Which pattern per solution

| Solution | A sidecar | B in front | C behind | D embedded |
|---|---|---|---|---|
| LiteLLM Auto Router | 🟡 preview endpoint | ✅ | ✅ | ✅ (Python SDK) |
| vLLM Semantic Router | 🟡 route preview | ✅ | ✅ | ❌ |
| Plano | 🟡 (call router model directly) | ✅ | ✅ | ❌ |
| Switchyard | ✅ `libsy` (Rust) | ✅ | ✅ | ✅ (Rust) |
| RouteLLM | ✅ | ✅ (its server) | ✅ | ✅ |
| LLMRouter | ✅ | ✅ (OpenClaw server) | ✅ | ✅ |
| Aurelio semantic-router | ✅ (wrap in FastAPI) | ❌ | ❌ | ✅ |
| NVIDIA classifier | ✅ (wrap in FastAPI) | ❌ | ❌ | ✅ (if GPU in API) |

---

## The routing contract (use this for Pattern A)

Standardize one contract so you can swap router implementations without touching your API.

**Request** `POST /route`

```json
{
  "request_id": "b3c1…",
  "session_id": "conv-8812",
  "messages": [
    {"role": "system", "content": "You are the ACME assistant…"},
    {"role": "user", "content": "Can you check this SQL for performance issues? …"}
  ],
  "metadata": {
    "user_id": "u-123",
    "team": "finance",
    "app": "chatbot-web",
    "previous_model": "general-small",
    "turn_index": 4,
    "has_attachments": false
  },
  "constraints": {
    "max_context_tokens": 12000,
    "allowed_models": ["fast-mini","general-small","general-large","code-specialist","reasoning-frontier"]
  }
}
```

**Response**

```json
{
  "model": "code-specialist",
  "confidence": 0.82,
  "tier": "COMPLEX",
  "reason": "rule:sql_detected → classifier:task=code_generation",
  "scores": {"fast-mini": 0.31, "general-small": 0.55, "general-large": 0.74, "code-specialist": 0.88, "reasoning-frontier": 0.90},
  "router_version": "r2026-10-20-knn-v3",
  "latency_ms": 14
}
```

**Rules for your API:**

1. **Timeout:** 50–100 ms. On timeout or error → `DEFAULT_MODEL` (choose a mid-tier like `general-small`). Never fail the user request because the router failed.
2. **Allow-list:** ignore any model not in `allowed_models` (defense against config mistakes).
3. **Explicit model wins:** if a client explicitly asks for a model (not `auto`), skip routing.
4. **Session policy:** apply affinity in the API (or router): within a session allow upgrades, avoid downgrades for N turns, re-route after a TTL.
5. **Log everything:** `request_id, session_id, router_version, chosen_model, reason, scores, latency, tokens, cost, user feedback`. This log *is* your future training set.

### Minimal integration code (Python, inside your API)

```python
import os, httpx, logging

ROUTER_URL = os.getenv("ROUTER_URL", "http://router-sidecar:8080/route")
DEFAULT_MODEL = os.getenv("ROUTER_DEFAULT_MODEL", "general-small")
ALLOWED = {"fast-mini", "general-small", "general-large", "code-specialist", "reasoning-frontier"}
SHADOW = os.getenv("ROUTER_SHADOW", "true") == "true"   # start in shadow mode

router_client = httpx.AsyncClient(timeout=httpx.Timeout(0.08))  # 80 ms hard budget
log = logging.getLogger("routing")

async def choose_model(req) -> str:
    if req.model and req.model != "auto":
        return req.model                                  # explicit choice wins
    decision = None
    try:
        r = await router_client.post(ROUTER_URL, json={
            "request_id": req.id, "session_id": req.session_id,
            "messages": req.messages, "metadata": req.metadata,
            "constraints": {"allowed_models": sorted(ALLOWED)},
        })
        r.raise_for_status()
        decision = r.json()
    except Exception as e:                                # timeout, 5xx, bad JSON…
        log.warning("router_fallback", extra={"err": str(e), "request_id": req.id})

    routed = decision["model"] if decision and decision.get("model") in ALLOWED else DEFAULT_MODEL
    served = req.legacy_model if SHADOW else routed      # shadow: keep old behavior
    log.info("routing_decision", extra={
        "request_id": req.id, "routed": routed, "served": served,
        "reason": decision and decision.get("reason"),
        "router_version": decision and decision.get("router_version"),
    })
    return served
```

---

## Pattern B in practice: exposing your API as the gateway's backend

All gateways in this pack accept an OpenAI-compatible backend with a custom base URL. The idea is identical everywhere — five backend entries, same base URL, different model alias:

```yaml
# Pseudocode common to all gateways
backends:
  fast-mini:          {base_url: $INFERENCE_API_BASE, model: fast-mini,          key: $INFERENCE_API_KEY}
  general-small:      {base_url: $INFERENCE_API_BASE, model: general-small,      key: $INFERENCE_API_KEY}
  general-large:      {base_url: $INFERENCE_API_BASE, model: general-large,      key: $INFERENCE_API_KEY}
  code-specialist:    {base_url: $INFERENCE_API_BASE, model: code-specialist,    key: $INFERENCE_API_KEY}
  reasoning-frontier: {base_url: $INFERENCE_API_BASE, model: reasoning-frontier, key: $INFERENCE_API_KEY}
```

Tool-specific syntax is in each guide.

**Things to align with your API:**

- **Pricing:** gateways compute cost/savings from a price catalog. For custom aliases they won't know prices — set custom per-token prices in the gateway config (LiteLLM supports custom pricing; Plano can read a pricing endpoint you host).
- **Streaming:** confirm SSE passthrough end-to-end (gateway ↔ your API).
- **Headers:** propagate `user`, `session_id`, and tracing headers (W3C `traceparent`) so you can join logs.
- **Auth:** the gateway holds a service key for your API; end-user identity travels in headers/metadata, not keys.
- **Model names in responses:** decide whether clients see `smart-router` or the real model (LiteLLM `return_raw_model_name`; header `x-litellm-model-id`).

---

## Latency budget

| Component | Typical | Notes |
|---|---|---|
| Rules / heuristics | < 1 ms | |
| Local embedding (small model, CPU) | 5–20 ms | GPU: 1–5 ms |
| DeBERTa/BERT classifier (GPU) | 5–30 ms | CPU: 30–150 ms for 512 tokens |
| kNN / MLP on embedding | < 2 ms | |
| Remote embedding API | 100–500 ms | LiteLLM docs cite this range for its legacy semantic router |
| Router LLM 1.5B (GPU, vLLM) | 50–300 ms | depends on output length; route JSON is short |
| Extra gateway hop in-cluster | 1–5 ms | |

Target for a chatbot: **routing decision p95 < 50 ms**; it's invisible next to time-to-first-token.

---

## Failure modes and safeguards

| Failure | Safeguard |
|---|---|
| Router down / slow | Timeout + default model; circuit breaker (stop calling for 30 s after N timeouts) |
| Router returns unknown model | Allow-list check |
| Bad router release | Version every router; canary 5% → 25% → 100%; instant rollback flag |
| Chosen model down | Your API's existing fallback chain; prefer falling **up** a tier |
| Cost spike (router over-escalates) | Daily budget alarm on strong-call %; automatic λ increase or cap |
| Quality drop (router under-routes) | Monitor regenerate/thumbs-down per model; auto-raise floor for affected intents |

---

## Security & privacy checklist

- Router sees full prompts → treat it as a **production data processor** (same data classification as your API).
- No hosted router endpoints for sensitive traffic (Plano defaults to a hosted router model — override `llm_routing_model` to a self-hosted one).
- Disable telemetry where it exists (`SWITCHYARD_TELEMETRY_OPT_OUT=1`).
- Classifier/embedding models downloaded once into your registry/artifact store; pin hashes.
- Logs containing prompts: apply your retention and PII policy; consider logging embeddings + hashed text for training instead of raw text.

Next: pick a guide in [`../02-guides/`](../02-guides/).
